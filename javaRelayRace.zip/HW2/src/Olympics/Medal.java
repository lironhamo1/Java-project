package Olympics;

import java.util.Arrays;

import animals.Dolphin.WaterType;

public class Medal {
	/**
	 * A new enum type that call type
	 */
	public enum type {
		silver, gold, bronze
	};

	/**
	 * A type(enum) field that describe the type of the medal object
	 */
	private type type;
	/**
	 * A string field that describe the name's tournament of the medal
	 */
	private String tournament;

	/**
	 * A int field that describe the year of the medal
	 */
	private int year;

	/**
	 * default constructor
	 */
	public Medal() {
		this.setType(type.silver);
		this.setTournament("Israel");
		this.setYear(2020);
	}

	/**
	 * constructor
	 * 
	 * @param x -the type of medal
	 * @param tournament -the tournament of get the medal
	 * @param year- of get the medal
	 */
	public Medal(type x, String tournament, int year) {
		this.setType(x);
		this.setTournament(tournament);
		this.setYear(year);
	}

	/**
	 * method that return the type of the medal
	 * 
	 * @return type(type)
	 */
	public type getType() {
		return type;
	}
	/**
	 * boolean set method that change the medal's type,return true after the change
	 * @param Type- type of medal's type (type type)
	 * @return boolean value
	 */
	public boolean setType(type Type) {
				this.type=Type;
				return true;
	}

	/**
	 * method that return the tournament of the medal
	 * 
	 * @return type(type)
	 */
	public String getTournament() {
		return tournament;
	}
	/**
	 * boolean method that change the tournament of the medal
	 * @param tournament- the tournament of get the medal 
	 * @return boolean value
	 */
	public boolean setTournament(String tournament) {
		this.tournament = tournament;
		return true;
	}
	/**
	 * method that return the year of the medal
	 * 
	 * @return year(int)
	 */
	public int getYear() {
		return year;
	}

	/**
	 * boolean method that change the year of the medal
	 * @param year of get the medal (int)
	 * @return boolean value
	 */
	public boolean setYear(int year) {
		this.year = year;
		return true;
	}

	/**
	 * Overloaded method that return a string of the medal object's details
	 * 
	 * @return String
	 */
	public String toString() {

		return type + " " + tournament + " " + year + " ";

	}

}
