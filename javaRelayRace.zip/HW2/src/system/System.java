package system;

/**
 * The program is about a initialize a zoo and than you can talk with the animals and see there information
 * @author Liron Hamo ,ID:207973603
 */
import java.util.Scanner;
import Olympics.Medal;
import Olympics.Medal.type;
import animals.*;
import animals.Animal.gender;
import animals.Dolphin.WaterType;
import animals.Snake.Poisonous;
import mobility.Point;

public class System {

	/**
	 * A variable that we can get input through all the class
	 */
	static Scanner IO = new Scanner(java.lang.System.in);

	/**
	 * The Main Method
	 * 
	 * @param args[] - default parameters of main function
	 */
	public static void main(String args[]) {
		int size, choice;
		java.lang.System.out.println("enter number of animals at zoo");
		size = IO.nextInt();
		Animal[] arr = new Animal[size];// create animal array
		for (int i = 0; i < size; i++) {
			arr[i] = createAnimal();
		}
		java.lang.System.out.println("thank you of the initilize the zoo!\n");
		do {
			java.lang.System.out.println(
					"MENU:\n1 for the information about the animals\n2 for speek with the animals\n3 to exit from zoo\n");
			choice = IO.nextInt();
			switch (choice) {
			case 1:
				infoZoo(arr);
				break;
			case 2:
				speekZoo(arr);
				break;
			case 3:
				break;
			default:
				java.lang.System.out.print("invaild value");
			}
		} while (choice != 3);
		java.lang.System.out.println("Thank you for visiting our zoo !\n");

	}

	/**
	 * 
	 * Method that call the function makeSound in a loop and it print the sound of
	 * the animals
	 * 
	 * @param a Animal array
	 * @see Animal sound
	 * 
	 */
	public static void speekZoo(Animal[] a) {
		for (int i = 0; i < a.length; i++) {
			a[i].makeSound();
		}
	}

	/**
	 * 
	 * Method that call to function toString and print respectively the information
	 * of the animals at the zoo
	 * 
	 * @param a Animal array
	 * @see Animal information
	 * 
	 */
	public static void infoZoo(Animal a[]) {
		for (int i = 0; i < a.length; i++) {
			java.lang.System.out.println(a[i].toString());
		}
	}

	/**
	 * Method that create a animal in the zoo, the user choice the type of the
	 * animal
	 * 
	 * @return Animal object
	 */
	public static Animal createAnimal() {
		Animal animal = null;
		int type;
		do {
			java.lang.System.out.println("for Air Animal:1\nfor Water Animal:2\nfor Terrestrial Animal:3 ");
			type = IO.nextInt();
			switch (type) {
			case 1:
				return animal = createAirAnimal(type);
			case 2:
				return animal = createWaterAnimal(type);
			case 3:
				return animal = createTerrestrialAnimal(type);
			default:
				java.lang.System.out.println("invaild value");
			}
		} while (type > 3 || type < 1);
		return animal;
	}

	/**
	 * Method that create a terrestrial animal, the user choice the specific animal
	 * 
	 * @param type: the type of the animal
	 * @return Animal object
	 */
	private static Animal createTerrestrialAnimal(int type) {
		Animal animal = null;
		java.lang.System.out.println("for Dog:1\nfor Cat:2\nfor Snake:3\n");
		int choice = IO.nextInt();
		animal = InitAnimal(type, choice);
		return animal;
	}

	/**
	 * Method that create a water animal, the user choice the specific animal
	 * 
	 * @param type:the type of the animal
	 * @return Animal object
	 */
	private static Animal createWaterAnimal(int type) {
		Animal animal = null;
		java.lang.System.out.println("for Alligator:1\nfor Whale:2\nfor Dolphin:3\n");
		int choice = IO.nextInt();
		animal = InitAnimal(type, choice);
		return animal;
	}

	/**
	 * Method that create a air animal, the user choice the specific animal
	 * 
	 * @param type: the type of the animal
	 * @return Animal object
	 */
	private static Animal createAirAnimal(int type) {
		Animal animal = null;
		java.lang.System.out.println("for Eagle:1\nfor Pegeon:2\n");
		int choice = IO.nextInt();
		animal = InitAnimal(type, choice);
		return animal;

	}

	/**
	 * Method that create a water animal, the user choice the specific animal
	 * 
	 * @param type:   number of animal's type
	 * @param choice: number of the specific animal
	 * @return Sub-Animal object (depend on the chosen animal)
	 */
	private static Animal InitAnimal(int type, int choice) {
		Animal animal = null;
		String name = getName();
		gender gender = getGender();
		double weight = getWeight();
		double speed = getSpeed();
		Medal medals[] = getMedals();
		Point position = getPosition();
		if (type == 1) {// Air
			double wingspan = getWingspan();
			if (choice == 1) {
				return animal = createEagle(name, gender, weight, speed, medals, position, wingspan);
			} else {
				return animal = createPigeon(name, gender, weight, speed, medals, position, wingspan);
			}
		}
		if (type == 2) {// water
			double diveDept = getDive();
			if (choice == 1) {
				return animal = createAlligator(name, gender, weight, speed, medals, position, diveDept);
			}
			if (choice == 2) {
				return animal = createWhale(name, gender, weight, speed, medals, position, diveDept);
			} else {
				return animal = createDolphin(name, gender, weight, speed, medals, position, diveDept);
			}
		}
		if (type == 3) {
			int noLegs = getLegs();
			if (choice == 1) {
				return animal = createDog(name, gender, weight, speed, medals, position, noLegs);
			}
			if (choice == 2) {
				return animal = createCat(name, gender, weight, speed, medals, position, noLegs);
			} else {
				return animal = createSnake(name, gender, weight, speed, medals, position, noLegs);
			}
		}
		return animal;
	}

	/**
	 * Method that create a snake
	 * 
	 * @param name     - name of the snake object (String)
	 * @param gender   -gender of the snake object (enum)
	 * @param weight   - weight of the snake object(double)
	 * @param speed    - speed of the snake object (double)
	 * @param medals   -Medal's array of the snake object(Medal)
	 * @param position -point of the snake object(Point)- can be null
	 * @return Snake object
	 */
	private static Animal createSnake(String name, gender gender, double weight, double speed, Medal[] medals,
			Point position, int noLegs) {
		Snake x;
		Poisonous poisonous = getPoisonous();
		java.lang.System.out.println("enter the length of the snake: ");
		double length = IO.nextInt();
		if (position != null) {
			x = new Snake(name, gender, weight, speed, medals, position, noLegs, poisonous, length);
		} else
			x = new Snake(name, gender, weight, speed, medals, noLegs, poisonous, length);
		return x;
	}

	/**
	 * Method that initialize the snake's poisonous (yes or no)
	 * 
	 * @return Poisonous enum
	 */
	private static Poisonous getPoisonous() {
		int type;

		Poisonous poisonous = null;
		do {
			java.lang.System.out.println("is the snake poisonous? press 1 to no, press 2 to yes");
			type = IO.nextInt();
			switch (type) {
			case 1:
				poisonous = Poisonous.no;
				break;
			case 2:
				poisonous = Poisonous.yes;
				break;
			default:
				java.lang.System.out.println("invaild value");
			}
		} while (type > 2 || type < 1);
		return poisonous;
	}

	/**
	 * Method that create a cat
	 * 
	 * @param name     - name of the cat object (String)
	 * @param gender   -gender of the cat object (enum)
	 * @param weight   - weight of the cat object(double)
	 * @param speed    - speed of the cat object (double)
	 * @param medals   -Medal's array of the cat object(Medal)
	 * @param position -point of the cat object(Point)- can be null
	 * @return Cat object
	 */
	private static Animal createCat(String name, gender gender, double weight, double speed, Medal[] medals,
			Point position, int noLegs) {
		Cat x;
		boolean Castrated = isCastrat();
		if (position != null)
			x = new Cat(name, gender, weight, speed, medals, position, noLegs, Castrated);
		else
			x = new Cat(name, gender, weight, speed, medals, noLegs, Castrated);
		return x;
	}

	/**
	 * Method that initialize the cat's castrated (yes or no)
	 * 
	 * @return boolean value
	 */
	private static boolean isCastrat() {
		int choose;
		do {
			java.lang.System.out.println("if the cat is castrated press 1,else press 2 ");
			choose = IO.nextInt();
			switch (choose) {
			case 1:
				return true;
			case 2:
				return false;
			default:
				java.lang.System.out.println("invaild value=no cadtrated");
				return false;
			}
		} while (choose > 2 || choose < 1);
	}

	/**
	 * Method that create a dog
	 * 
	 * @param name     - name of the dog object (String)
	 * @param gender   -gender of the dog object (enum)
	 * @param weight   - weight of the dog object(double)
	 * @param speed    - speed of the dog object (double)
	 * @param medals   -Medal's array of the dog object(Medal)
	 * @param position -point of the dog object(Point)- can be null
	 * @return Dog object
	 */
	private static Animal createDog(String name, gender gender, double weight, double speed, Medal[] medals,
			Point position, int noLegs) {
		Dog x;
		java.lang.System.out.println("enter breed type: ");
		String breed = IO.next();
		if (position != null)
			x = new Dog(name, gender, weight, speed, medals, position, noLegs, breed);
		else
			x = new Dog(name, gender, weight, speed, medals, noLegs, breed);
		return x;
	}

	/**
	 * Method that create a dolphin
	 * 
	 * @param name      - name of the dolphin object (String)
	 * @param gender    -gender of the dolphin object (enum)
	 * @param weight    - weight of the dolphin object(double)
	 * @param speed     - speed of the dolphin object (double)
	 * @param medals    -Medal's array of the dolphin object(Medal)
	 * @param diveDept- the divedept of the dolphin(double)
	 * @param position  -point of the dolphin object(Point)- can be null
	 * @return Dolphin object
	 */
	public static Animal createDolphin(String name, gender gender, double weight, double speed, Medal[] medals,
			Point position, double diveDept) {
		Dolphin x;
		WaterType watertype = getWaterType();
		if (position != null)
			x = new Dolphin(name, gender, weight, speed, medals, position, diveDept, watertype);
		else
			x = new Dolphin(name, gender, weight, speed, medals, diveDept, watertype);
		return x;
	}

	/**
	 * Method that initialize the dolphin's water type (see or sweet)
	 * 
	 * @return waterType enum
	 */
	private static WaterType getWaterType() {
		WaterType waterType = null;
		int type;
		do {
			java.lang.System.out.println("enter type of dolphin: 1=sea, 2=sweet");
			type = IO.nextInt();
			switch (type) {
			case 1:
				waterType = WaterType.Sea;
				break;
			case 2:
				waterType = WaterType.Sweet;
				break;
			default:
				java.lang.System.out.print("invaild value");
			}
		} while (type > 2 || type < 1);
		return waterType;
	}

	/**
	 * Method that create a whale
	 * 
	 * @param name     - name of the whale object (String)
	 * @param gender   -gender of the whale object (enum)
	 * @param weight   - weight of the whale object(double)
	 * @param speed    - speed of the whale object (double)
	 * @param medals   -Medal's array of the whale object(Medal)
	 * @param position -point of the whale object(Point)- can be null
	 * @return Whale object
	 */
	private static Animal createWhale(String name, gender gender, double weight, double speed, Medal[] medals,
			Point position, double diveDept) {
		Whale x;
		java.lang.System.out.println("enter food type: ");
		String foodType = IO.next();
		if (position != null)
			x = new Whale(name, gender, weight, speed, medals, position, diveDept, foodType);
		else
			x = new Whale(name, gender, weight, speed, medals, diveDept, foodType);
		return x;
	}

	/**
	 * Method that create a alligator
	 * 
	 * @param name     - name of the alligator object (String)
	 * @param gender   -gender of the alligator object (enum)
	 * @param weight   - weight of the alligator object(double)
	 * @param speed    - speed of the alligator object (double)
	 * @param medals   -Medal's array of the alligator object(Medal)
	 * @param position -point of the alligator object(Point)- can be null
	 * @return Alligator object
	 */
	private static Animal createAlligator(String name, gender gender, double weight, double speed, Medal[] medals,
			Point position, double diveDept) {
		Alligator x;
		java.lang.System.out.println("enter area of living: ");
		String AreaOfLiving = IO.next();
		if (position != null)
			x = new Alligator(name, gender, weight, speed, medals, position, diveDept, AreaOfLiving);
		else
			x = new Alligator(name, gender, weight, speed, medals, diveDept, AreaOfLiving);
		return x;

	}

	/**
	 * Method that create a Pigeon
	 * 
	 * @param name     - name of the Pigeon object (String)
	 * @param gender   -gender of the Pigeon object (enum)
	 * @param weight   - weight of the Pigeon object(double)
	 * @param speed    - speed of the Pigeon object (double)
	 * @param medals   -Medal's array of the Pigeon object(Medal)
	 * @param position -point of the Pigeon object(Point)- can be null
	 * @return Pigeon object
	 */
	private static Animal createPigeon(String name, gender gender, double weight, double speed, Medal[] medals,
			Point position, double wingspan) {
		Pigeon x;
		java.lang.System.out.println("enter family of the pigeon: ");
		String family = IO.next();
		if (position != null)
			x = new Pigeon(name, gender, weight, speed, medals, position, wingspan, family);
		else
			x = new Pigeon(name, gender, weight, speed, medals, wingspan, family);
		return x;
	}

	/**
	 * Method that initialize the position of the animal, there is option to not
	 * initilize it
	 * 
	 * @return Point object
	 * @return null
	 */
	
	private static Point getPosition() {
		int choice;
		do {
		java.lang.System.out.println("did you want enter new position? 1 for yes,2 for no");
		choice = IO.nextInt();
		switch (choice) {
		case 1:
			java.lang.System.out.println("enter x and y of the position");
			int xp = IO.nextInt();
			int yp = IO.nextInt();
			Point P = new Point(xp, yp);
			return P;
		case 2:
			return null;
		default:
			java.lang.System.out.println("invaild value\n");
			break;
		}
		}while(choice>2 || choice <1);
		return null;
	}

	/**
	 * Method that create a Eagle
	 * 
	 * @param name      - name of the Eagle object (String)
	 * @param gender    -gender of the Eagle object (enum)
	 * @param weight    - weight of the Eagle object(double)
	 * @param speed     - speed of the Eagle object (double)
	 * @param medals    -Medal's array of the Eagle object(Medal)
	 * @param position  -point of the Eagle object(Point)- can be null
	 * @param wingspan- the wingspan of the Eagle object(double)
	 * @return Eagle object
	 */
	public static Animal createEagle(String name, gender gender, double weight, double speed, Medal[] medals,
			Point position, double wingspan) {
		Eagle x;
		java.lang.System.out.println("enter the altitudeOfFlight: ");
		double altitudeOfFlight = IO.nextDouble();
		if (position != null) {
			x = new Eagle(name, gender, weight, speed, medals, position, wingspan, altitudeOfFlight);
		} else {
			x = new Eagle(name, gender, weight, speed, medals, wingspan, altitudeOfFlight);
		}
		return x;
	}

	/**
	 * Method that receive the number of animal terrestrial's legs.
	 * 
	 * @return leg's number(int)
	 */
	private static int getLegs() {
		java.lang.System.out.println("enter number of legs ");
		int legs = IO.nextInt();
		return legs;
	}

	/**
	 * Method that receive the divedept of water animal.
	 * 
	 * @return divedept(double)
	 */
	private static double getDive() {
		java.lang.System.out.println("enter a divedept: ");
		double diveDept = IO.nextDouble();
		return diveDept;
	}

	/**
	 * Method that receive the number of air animal's wingspan.
	 * 
	 * @return wingspan(double)
	 */
	private static double getWingspan() {
		java.lang.System.out.println("enter num of wingspan: ");
		double wingspan = IO.nextDouble();
		return wingspan;
	}

	/**
	 * Method that initialize the medal's array of animal.
	 * 
	 * @return Medal's array
	 */
	private static Medal[] getMedals() {
		java.lang.System.out.print("enter num of medals\n");
		int numMedals = IO.nextInt();
		int typeMedal, year;
		type type = null;
		String tournament;
		Medal medal[] = new Medal[numMedals];
		for (int j = 0; j < numMedals; j++) {
			do {
				java.lang.System.out.println("enter type of medal number" + (j + 1) + ":\n1 bronze\n2 silver\n3 gold ");
				typeMedal = IO.nextInt();
				switch (typeMedal) {
				case 1:
					type = type.bronze;
					break;
				case 2:
					type = type.silver;
					break;
				case 3:
					type = type.gold;
					break;
				default:
					java.lang.System.out.print("invaild value\n");
				}
			} while (typeMedal > 3 || typeMedal < 1);
			java.lang.System.out.println("enter tournament");// and year of this medal");
			tournament = IO.next();
			java.lang.System.out.println("enter year");
			year = IO.nextInt();
			medal[j] = new Medal(type, tournament, year);
		}
		return medal;
	}

	/**
	 * Method that receive the number of animal's speed.
	 * 
	 * @return speed(double)
	 */
	private static double getSpeed() {
		java.lang.System.out.print("enter speed\n");
		double speed = IO.nextDouble();
		return speed;
	}

	/**
	 * Method that receive the weight of animal.
	 * 
	 * @return weight(double)
	 */
	private static double getWeight() {
		java.lang.System.out.print("enter weight\n");
		double weight = IO.nextDouble();
		return weight;
	}

	/**
	 * Method that receive the gender of animal
	 * 
	 * @return gender enum
	 */
	private static gender getGender() {
		int genderNum;
		gender gender = null;
		do {
			java.lang.System.out.println("enter gender: \n1 to Male\n2 Female\n3 Hermaphrodite");
			genderNum = IO.nextInt();
			switch (genderNum) {
			case 1:
				gender = gender.Male;
				break;
			case 2:
				gender = gender.Male;
				break;
			case 3:
				gender = gender.Hermaphrodite;
				break;
			default:
				java.lang.System.out.print("invaild value\n");
			}
		} while (genderNum > 3 || genderNum < 1);
		return gender;
	}

	/**
	 * Method that receive the name of animal
	 * 
	 * @return name(String)
	 */
	private static String getName() {
		java.lang.System.out.println("enter name of the animal");
		String name = IO.next();
		return name;
	}
}
