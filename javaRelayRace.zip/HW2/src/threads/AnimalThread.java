package threads;

import java.awt.Graphics;
import java.io.InputStream;
import java.util.Scanner;
import java.util.concurrent.atomic.AtomicBoolean;

import animals.Animal;
import animals.Animal.Orientation;
import competitions.Scores;
import mobility.Point;

public class AnimalThread implements Runnable {
	Animal participant;
	AtomicBoolean startFlag;
	AtomicBoolean finishFlag;
	int neededDistance;
	int sleepTime = 5000;
	Scanner IO = new Scanner(System.in);
/**
 * 
 * @param a animal object
 * @param startFlag The flag that says when the animal need to start moving
 * @param finishFlag The flag that says when the animal finish 
 * @param neededDistance the distance the animal need to move
 */
	public AnimalThread(Animal a, AtomicBoolean startFlag, AtomicBoolean finishFlag, int neededDistance) {
		participant = a;
		this.startFlag = startFlag;
		this.finishFlag = finishFlag;
		this.neededDistance = neededDistance;
	}

	/**
	 * 
	 * @param a animal object
	 * @param startFlag The flag that says when the animal need to start moving
	 * @param finishFlag The flag that says when the animal finish 
	 */
	public AnimalThread(Animal a, AtomicBoolean startFlag, AtomicBoolean finishFlag) {
		participant = a;
		this.startFlag = startFlag;
		this.finishFlag = finishFlag;
		if (participant.returnType() == "Land") {
			this.neededDistance = 1960;
		} else {
			this.neededDistance = 580;
		}

	}

	/**
	 * Checks whether the animal has where to move
		if true move
		else update location to finish line
	 */
	void moveAnimal() {
		int x = participant.getLocation().getX();
		int y = participant.getLocation().getY();
		int s = HowMuchMove();
		if (x+s>580) {
			participant.move(new Point(580, y));
		}
		else {
		participant.move(new Point(x + s, y));
		}
		participant.setTotalDistance(participant.getTotalDistance() + HowMuchMove());
	}

	/**
	 * Checks whether the animal has where to move
		if true move
		else update location to finish line
		update total distance 
	 */
	void moveLand() {
		int limitX = 580;
		int limitY = 400;
		if ((participant.getLocation().getX() + HowMuchMove() <= limitX)
				&& (participant.getLocation().getY() == limitY)) {
			participant.setLocation(new Point(participant.getLocation().getX() + HowMuchMove(), limitY));
			participant.setorien(Orientation.EAST);
			// System.out.println("p 1");
		}
		if ((participant.getLocation().getX() + HowMuchMove() > limitX)
				&& (participant.getLocation().getY() <= limitY)) {
			participant.setLocation(new Point(limitX, participant.getLocation().getY() - HowMuchMove()));
			participant.setorien(Orientation.NORTH);
			// System.out.println("p 2");
		}
		if ((participant.getLocation().getX() <= limitX) && (participant.getLocation().getY() - HowMuchMove() <= 0)) {
			participant.setLocation(new Point(participant.getLocation().getX() - HowMuchMove(), 0));
			participant.setorien(Orientation.WEST);
			// System.out.println("p 3");
		}
		if ((participant.getLocation().getX() - HowMuchMove() < 0) && (participant.getLocation().getY() < limitY)) {
			participant.setLocation(new Point(0, participant.getLocation().getY() + HowMuchMove()));
			participant.setorien(Orientation.SOUTH);
			// System.out.println("p 4");
		}

		participant.setTotalDistance(participant.getTotalDistance() + HowMuchMove());

	}

	/**
	 * 
	 * @return the distance the animal need to move 
	 */
	public int HowMuchMove() {
		int move;
		int energyNow = participant.getEnergyNow();
		int speed = (int) participant.getSpeed();
		int energyPerMeter = participant.getEnergyPerMeter();
		move = speed* energyNow / energyPerMeter;
		return move;
	}

	@Override
	public void run() {
		synchronized (startFlag) {
			while (startFlag.get() == false) {
				try {
					startFlag.wait();
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
			synchronized (participant) {
				int distance = 0;
				while (distance <= neededDistance) {
					if (participant.returnType() == "Land") {
						moveLand();
					} else {

						moveAnimal();
					}
					distance++;
					try {
						Thread.sleep(20);
						// Thread.interrupted();
					} catch (InterruptedException ie) {
						System.out.println(ie);
					}

				}
				finishFlag.set(true);
				synchronized (finishFlag) {
					finishFlag.notify();
				}
				// startFlag.notify();
				System.out.println("notify done");
				try {
					Thread.sleep(sleepTime);

				} catch (InterruptedException ie) {
					System.out.println(ie);
				}
			}
		}
	}
}