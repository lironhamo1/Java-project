module HW2 {
	requires java.desktop;
}