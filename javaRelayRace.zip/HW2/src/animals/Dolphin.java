package animals;

import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

import Olympics.Medal;
import animals.Animal.Orientation;
import animals.Animal.gender;
import graphics.CompetitionPanel;
import mobility.Point;
/**
 * class Dolphin to create a dolphin, it inherits from WaterAnimal class
 * 
 * @author liron
 *
 */
public class Dolphin extends WaterAnimal {
	/**
	 * A new enum type that call WaterType
	 */
	public enum WaterType {
		Sea, Sweet
	};

	/**
	 * A WaterType(enum) field that describe the water type of the animal
	 */
	private WaterType Watertype;

//animal-individual-sound: Click-click

	/**
	 * a default constructor- no parameters
	 */
	public Dolphin() {
		super();
		this.Watertype = WaterType.Sea;
		this.setSound("Click-click");
	}

	
	
	
	
	/**
	 * Constructor
	 * 
	 * @param name       - name of the Dolphin object (String)
	 * @param g     -gender of the Dolphin object (enum)
	 * @param weight     - weight of the Dolphin object(double)
	 * @param speed      - speed of the Dolphin object (double)
	 * @param A          -Medal's array of the Dolphin object(Medal)
	 * @param position      -point of the Dolphin object(Point)
	 * @param dive       -the divedept of the Dolphin object(double)
	 * @param watertype- enum value of water type of the Dolphin object(WaterType)
	 * 
	 *                   call to the super class constructor
	 */
	public Dolphin(String name, animals.Animal.gender g, double weight, double speed, Medal[] A, Point position,
			double dive, WaterType watertype,int maxEnergy,int energyMeter,int size) {
		super(name, g, weight, speed, A, position, dive,"Click-click",maxEnergy,energyMeter,size);
		this.Watertype = watertype;
	}

	/**
	 * Constructor- without point
	 * 
	 * @param name       - name of the Dolphin object (String)
	 * @param g     -gender of the Dolphin object (enum)
	 * @param weight     - weight of the Dolphin object(double)
	 * @param speed      - speed of the Dolphin object (double)
	 * @param A          -Medal's array of the Dolphin object(Medal)
	 * @param dive       -the divedept of the Dolphin object(double)
	 * @param watertype- enum value of water type of the Dolphin object(WaterType)
	 * 
	 *                   call to the super class constructor
	 */
	public Dolphin(String name, animals.Animal.gender g, double weight, double speed, Medal[] A, double dive,
			WaterType watertype,int maxEnergy,int energyMeter,int size) {
		super(name, g, weight, speed, A, dive,"Click-click",maxEnergy,energyMeter, size);
		this.Watertype = watertype;
	}

	/**
	 * Method that return the Watertype field
	 * 
	 * @return Watertype (WaterType)
	 */
	public WaterType getWatertype() {
		return Watertype;
	}

	/**
	 * boolean set method that change the dolphine's watertype,return true after the
	 * change
	 * @param watertype the new water type
	 * @return boolean value
	 */
	public boolean setWatertype(WaterType watertype) {
		this.Watertype = watertype;
		return true;

	}

	/**
	 * Overloaded method that return a string of the dolphin's details call to
	 * superclass toString
	 * 
	 * @return String
	 */
	public String toString() {
		return super.toString() + " is water type:" + Watertype;
	}
	public void drawObject(Graphics g) {
		if (orientation == Orientation.EAST) // animal move to the east side
			g.drawImage(Img1, getLocation().getX(), getLocation().getY() - size / 10, size * 2, size, pan);
		else if (orientation == Orientation.SOUTH) // animal move to the south side
			g.drawImage(Img2, getLocation().getX(), getLocation().getY() - size / 10, size, size, pan);
		else {
			g.drawImage(Img1, getLocation().getX(), getLocation().getY(), size, size, pan);

		}
	}
	public String returnAnimal() {
		return "Dolphin";
	}


}
