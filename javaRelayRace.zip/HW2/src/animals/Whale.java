package animals;

import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

import Olympics.Medal;
import animals.Animal.Orientation;
import graphics.CompetitionPanel;
import mobility.Point;
/**
 * class Whale to create a whale, it inherits from WaterAnimal class
 * 
 * @author liron
 *
 */
public class Whale extends WaterAnimal {//������
	
	/**
	 * field of food type of the whale
	 */
	private  String foodType;
	//animal-individual-sound: Splash
	
	/**
	 * a default constructor- no parameters
	 */
	public Whale() {
		super();
		this.foodType="fish";
		this.setSound("Splash");
	}
	

	
	/**
	 * Constructor
	 * 
	 * @param name   - name of the Whale object (String)
	 * @param g -gender of the Whale object (enum)
	 * @param weight - weight of the Whale object(double)
	 * @param speed  - speed of the Whale object (double)
	 * @param A      -Medal's array of the Whale object(Medal)
	 * @param position  -point of the Whale object(Point)
	 * @param dive-  divedept of the Whale object(double)
	 * @param foodType- the type of food of the Whale object (String)
	 *  the constructor call
	 *               to the super classes to initialize the object
	 */
	public Whale(String name, animals.Animal.gender g, double weight, double speed, Medal[] A, Point position,
			double dive,String foodType,int maxEnergy,int energyMeter,int size) {
		super(name, g, weight, speed, A, position, dive,"Splash",maxEnergy,energyMeter,size);
		this.foodType=foodType;
		this.loadImages("whale1");
	}
	
	/**
	 * Constructor- without point
	 * 
	 * @param name   - name of the Whale object (String)
	 * @param g -gender of the Whale object (enum)
	 * @param weight - weight of the Whale object(double)
	 * @param speed  - speed of the Whale object (double)
	 * @param A      -Medal's array of the Whale object(Medal)
	 * @param dive-  divedept of the Whale object(double)
	 * @param foodType- the type of food of the Whale object (String)
	 *  the constructor call
	 *               to the super classes to initialize the object
	 */
	public Whale(String name, animals.Animal.gender g, double weight, double speed, Medal[] A,
			double dive,String foodType,int maxEnergy,int energyMeter,int size) {
		super(name, g, weight, speed, A, dive,"Splash",maxEnergy,energyMeter,size);
		this.foodType=foodType;
		this.loadImages("whale1");
	}
	
	/**
	 * Method that return the foodType field
	 * 
	 * @return foodType (String)
	 */
	public String getFoodType() {
		return foodType;
	}
	/**
	 * boolean set method that change the Whale's length,return true after the change
	 * @param foodType - the type's food of the whale (String)
	 * @return boolean value
	 */
	public boolean setFoodType(String foodType) {
		this.foodType = foodType;
		return true;
	}
	
	/**
	 * Overloaded method that return a string of the whale's details
	 * call to superclass toString
	 * @return String
	 */
	public String toString() {
		return super.toString()+ " food type:"+ foodType;
	}
	
	public void drawObject(Graphics g) {
		if (orientation == Orientation.EAST) // animal move to the east side
			g.drawImage(Img1, getLocation().getX(), getLocation().getY() - size / 10, size * 2, size, pan);
		else if (orientation == Orientation.SOUTH) // animal move to the south side
			g.drawImage(Img2, getLocation().getX(), getLocation().getY() - size / 10, size, size, pan);
		else {
			g.drawImage(Img1, getLocation().getX(), getLocation().getY(), size, size, pan);
		}
	}
	
	public String returnAnimal() {
		return "Whale";
	}
}
