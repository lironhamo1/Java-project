package animals;

import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

import Olympics.Medal;
import animals.Animal.Orientation;
import graphics.CompetitionPanel;
import mobility.Point;
/**
 * class Pigeon to create a pigeon, it inherits from AirAnimal class
 * 
 * @author liron
 *
 */
public class Pigeon extends AirAnimal{//����
	/**
	 * string field of the Pigeon's family
	 */
	private String family; 
	//animal-individual-sound: Arr-rar-rar-rar-raah
	/**
	 * a default constructor- no parameters
	 */
	public Pigeon() {
		super();
		this.family="arrh";
	}
	
	
	
	
	/**
	 * Constructor
	 * 
	 * @param name       - name of the Pigeon object (String)
	 * @param g     -gender of the Pigeon object (enum)
	 * @param weight     - weight of the Pigeon object(double)
	 * @param speed      - speed of the Pigeon object (double)
	 * @param A          -Medal's array of the Pigeon object(Medal)
	 * @param wings       -wingspan of the Pigeon object (double)
	 * @param position      -point of the Pigeon object(Point)
	 * @param family       -the family name of the Pigeon object(double)
	 * 
	 *                   call to the super class constructor
	 */
	public Pigeon(String name, animals.Animal.gender g, double weight, double speed, Medal[] A,Point position, double wings,String family,int maxEnergy,int energyMeter,int size) {
		super(name, g, weight, speed, A,position, wings,"Arr-rar-rar-rar-raah",maxEnergy,energyMeter,size);
		this.family=family;
	}
	/**
	 * Constructor-without point
	 * 
	 * @param name       - name of the Pigeon object (String)
	 * @param g     -gender of the Pigeon object (enum)
	 * @param weight     - weight of the Pigeon object(double)
	 * @param speed      - speed of the Pigeon object (double)
	 * @param A          -Medal's array of the Pigeon object(Medal)
	 * @param wings       -wingspan of the Pigeon object (double)
	 * @param family       -the family name of the Pigeon object(double)
	 * 
	 *                   call to the super class constructor
	 */
	public Pigeon(String name, animals.Animal.gender g, double weight, double speed, Medal[] A,double wings,String family,int maxEnergy,int energyMeter,int size) {
		super(name, g, weight, speed, A, wings,"Arr-rar-rar-rar-raah",maxEnergy,energyMeter,size);
		this.family=family;
	}
	
	
	/**
	 * Method that return the family field
	 * 
	 * @return family (String)
	 */
	public String getFamily() {
		return family;
	}

	/**
	 * boolean set method that change the Pigeon's family,return true after the change
	 * @param family- the family name of the pigeon
	 * @return boolean value
	 */
	public boolean setFamily(String family) {
		this.family = family;
		return true;
	}
	
	/**
	 * Overloaded method that return a string of the Eagle's details
	 * call to superclass toString
	 * @return String
	 */
	public String toString() {
		return super.toString()+" the family name:"+ family;
	}
	
	public void drawObject(Graphics g) {
		if (orientation == Orientation.EAST) // animal move to the east side
			g.drawImage(Img1, getLocation().getX(), getLocation().getY() - size / 10, size * 2, size, pan);
		else if (orientation == Orientation.SOUTH) // animal move to the south side
			g.drawImage(Img2, getLocation().getX(), getLocation().getY() - size / 10, size, size, pan);
		else {
			g.drawImage(Img1, getLocation().getX(), getLocation().getY(), size, size, pan);
		}
	}
	
	public void loadImages(String nm) {
		try {
			Img1 = ImageIO.read(new File("src/graphics/picture/pigeon1E.png"));
			System.out.println("load image1");
		} catch (IOException e) {
			System.out.println("cant load image1");
			this.Img1 = null;
		}
	}
	
	public String returnAnimal() {
		return "Pigeon";
	}

}
