package animals;

import java.awt.Graphics;
import java.awt.image.BufferedImage;

import Olympics.*;
import graphics.CompetitionPanel;
import mobility.*;
/**
 * class WaterAnimal to create a animal that live in the sea, inherits from Animal class
 * 
 * @author liron
 *
 */

public class WaterAnimal extends Animal {
	/**
	 * a field that can't change of the max dive of the animal 
	 */
	private static final int MAX_DIVE = -800;
	/**
	 * field of divedept of the animal
	 */
	private double diveDept;// ���� �����
	
	/**
	 * a default constructor- no parameters
	 */
	public WaterAnimal() {//Ctor default
		super();
		this.diveDept = -100;
	}
	
	/**
	 * Constructor
	 * 
	 * @param name     - name of the WaterAnimal object (String)
	 * @param g   -gender of the WaterAnimal object (enum)
	 * @param weight   - weight of the WaterAnimal object(double)
	 * @param speed    - speed of the WaterAnimal object (double)
	 * @param A   -Medal's array of the WaterAnimal object(Medal)
	 * @param position -point of the WaterAnimal object(Point)
	 * @param diveDept- the divedept of the WaterAnimal object(double)
	 *   @param sound- the sound that the animal make(String)
	 */
	public WaterAnimal(String name, gender g, double weight, double speed, Medal A[], Point position, double diveDept,String sound,int maxEnergy,int energyMeter,int size) {
		super(name, g, weight, speed, A, position,sound,maxEnergy,energyMeter,size);
		this.diveDept = Dive(diveDept);
	}
	
	/**
	 * Constructor-without point, use the default point
	 * 
	 * @param name     - name of the WaterAnimal object (String)
	 * @param g   -gender of the WaterAnimal object (enum)
	 * @param weight   - weight of the WaterAnimal object(double)
	 * @param speed    - speed of the WaterAnimal object (double)
	 * @param A   -Medal's array of the WaterAnimal object(Medal)
	 * @param diveDept- the divedept of the WaterAnimal object(double)
	 *   @param sound- the sound that the animal make(String)
	 */
	
	public WaterAnimal(String name, gender g, double weight, double speed, Medal A[], double diveDept,String sound,int maxEnergy,int energyMeter,int size) {//Ctor default position
		super(name,g, weight, speed, A,new Point(50,0),sound,maxEnergy,energyMeter, size);
		this.diveDept = diveDept;
	}
	
	/**
	 * Method that return the diveDept field
	 * 
	 * @return diveDept (double)
	 */
	public double getDiveDept() {
		return diveDept;
	}

	/**
	 * Method that change the diveDept field
	 * @param x the new divedept (double)
	 * @return diveDept (double)
	 */
	public double Dive(double x) {
		if (diveDept + x >= MAX_DIVE) {
			diveDept = MAX_DIVE;
		} 
		else
			diveDept += x;
		return diveDept;
	}
	
	/**
	 * Overloaded method that return a string of the water animal's details
	 * call to superclass toString
	 * @return String
	 */
	public String toString() {
		return super.toString()+ "dive of dept:"+ diveDept;
	}

	public BufferedImage getImg1() {
		return Img1;
	}

	public void setImg1(BufferedImage img1) {
		Img1 = img1;
	}

	public String returnType() {
		return "Water";
	}
	
	public void drawObject(Graphics g) {
		g.drawImage(Img1, getLocation().getX(), getLocation().getY(), size, size,pan);
	}

	@Override
	public String returnAnimal() {
		// TODO Auto-generated method stub
		return null;
	}


}
