package animals;

import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

import Olympics.Medal;
import animals.Animal.Orientation;
import animals.Animal.gender;
import graphics.CompetitionPanel;
import mobility.Point;

/**
 * class TerrestrialAnimals to create a animal that live on the ground, inherits
 * from Animal class
 * 
 * @author liron
 *
 */
public class TerrestrialAnimals extends Animal {

	/**
	 * a field of number of length of the terrestrial animals
	 */
	private int noLegs;// �� ������
	private int limtX = 580;
	private int limitY = 400;

	/**
	 * a default constructor- no parameters
	 */
	public TerrestrialAnimals() {
		super();
		this.setNoLegs(2);

	}

	/**
	 * Constructor
	 * 
	 * @param name     - name of the Terrestrial Animals object (String)
	 * @param g        -gender of the Terrestrial Animals object (enum)
	 * @param weight   - weight of the Terrestrial Animals object(double)
	 * @param speed    - speed of the Terrestrial Animals object (double)
	 * @param A        -Medal's array of the Terrestrial Animals object(Medal)
	 * @param position -point of the Terrestrial Animals object(Point)
	 * @param legs-    number of legs of the Terrestrial Animals object(double)
	 * @param sound-   the sound that the animal make(String) call to the superclass
	 *                 constructor
	 */
	public TerrestrialAnimals(String name, gender g, double weight, double speed, Medal A[], Point position, int legs,
			String sound, int maxEnergy, int energyMeter, int size) {
		super(name, g, weight, speed, A, position, sound, maxEnergy, energyMeter, size);
		this.setNoLegs(legs);

	}

	/**
	 * Constructor-without point- initialize a default point
	 * 
	 * @param name   - name of the Terrestrial Animals object (String)
	 * @param g      -gender of the Terrestrial Animals object (enum)
	 * @param weight - weight of the Terrestrial Animals object(double)
	 * @param speed  - speed of the Terrestrial Animals object (double)
	 * @param A      -Medal's array of the Terrestrial Animals object(Medal)
	 * @param legs-  number of legs of the Terrestrial Animals object(double)
	 * @param sound- the sound that the animal make(String) call to the superclass
	 *               constructor
	 */
	public TerrestrialAnimals(String name, gender g, double weight, double speed, Medal A[], int legs, String sound,
			int maxEnergy, int energyMeter, int size) {
		super(name, g, weight, speed, A, new Point(0, 20), sound, maxEnergy, energyMeter, size);
		this.setNoLegs(legs);
	}

	/**
	 * Method that return the number of legs
	 * 
	 * @return noLegs(int)
	 */
	public int getNoLegs() {
		return noLegs;
	}

	/**
	 * boolean set method that change the number of legs,return true after the
	 * change
	 * 
	 * @param noLegs -number of animal's legs
	 * @return boolean value
	 */
	public boolean setNoLegs(int noLegs) {
		this.noLegs = noLegs;
		return true;
	}

	/**
	 * Overloaded method that return a string of the Snake's details call to
	 * superclass toString
	 * 
	 * @return String
	 */
	public String toString() {
		return super.toString() + "number of legs:" + noLegs;
	}

	public String returnType() {
		return "Land";
	}

	public void drawObject(Graphics g) {
		if (orientation == Orientation.EAST) // animal move to the east side
			g.drawImage(Img1, getLocation().getX(), getLocation().getY(), size, size, pan);
		else if (orientation == Orientation.NORTH) // animal move to the south side
			g.drawImage(Img2, getLocation().getX(), getLocation().getY(), size, size, pan);
		else if (orientation == Orientation.WEST) // animal move to the west side
			g.drawImage(Img3, getLocation().getX(), getLocation().getY(), size, size, pan);
		else if (orientation == Orientation.SOUTH) // animal move to the north side
			g.drawImage(Img4, getLocation().getX(), getLocation().getY(), size, size, pan);
		else {
			g.drawImage(Img1, getLocation().getX(), getLocation().getY(), size, size, pan);
		}
	}

	@Override
	public String returnAnimal() {
		// TODO Auto-generated method stub
		return null;
	}

	public void loadImages(String nm) {
		try {
			Img1 = ImageIO.read(new File("src\\graphics\\picture\\" + nm + "E.png"));
		} catch (IOException e) {
			System.out.println("cant load image");
			this.Img1 = null;
		}
		try {
			Img2 = ImageIO.read(new File("src\\graphics\\picture\\" + nm + "N.png"));
		} catch (IOException e) {
			System.out.println("cant load image");
			this.Img2 = null;

		}
		try {
			Img3 = ImageIO.read(new File("src\\graphics\\picture\\" + nm + "W.png"));
		//System.out.println("load image 3");
		} catch (IOException e) {
			System.out.println("cant load image");
			this.Img3 = null;

		}
		try {
			Img4 = ImageIO.read(new File("src\\graphics\\picture\\" + nm + "S.png"));
			//System.out.println("load image 4");
		} catch (IOException e) {
			System.out.println("cant load image");
			this.Img4 = null;
		}

	}

	public boolean eat(int e) {

		if (e <= 0) {

			return false;
		}

		if (this.energyNow - this.energyPerMeter >= 0) {
			if (this.energyNow + e >= this.maxEnergy) {
				this.energyNow = this.maxEnergy;
			} else {
				this.energyNow = this.energyNow + e;
			}
			this.energyNow = this.energyNow - this.energyPerMeter;
			if ((this.getLocation().getX() + this.energyPerMeter <= limtX) && (this.getLocation().getY() == limitY)) {
				this.setLocation(new Point(this.getLocation().getX() + this.energyPerMeter, limitY));
				this.setorien(orientation.EAST);
				System.out.println("p 1");
			}
			if ((this.getLocation().getX() + this.energyPerMeter > limtX) && (this.getLocation().getY() <= limitY)) {
				this.setLocation(new Point(limtX, this.getLocation().getY() - this.energyPerMeter));
				this.setorien(orientation.NORTH);
				System.out.println("p 2");
			}
			if ((this.getLocation().getX() <= limtX) && (this.getLocation().getY() - this.energyPerMeter <= 0)) {
				this.setLocation(new Point(this.getLocation().getX() - this.energyPerMeter, 0));
				this.setorien(orientation.WEST);
				System.out.println("p 3");
			}
			if ((this.getLocation().getX() - this.energyPerMeter < 0) && (this.getLocation().getY() < limitY)) {
				this.setLocation(new Point(0, this.getLocation().getY() + this.energyPerMeter));
				this.setorien(orientation.SOUTH);
				System.out.println("p 4");
			}

			this.setTotalDistance(this.getTotalDistance() + this.energyPerMeter);

		}
		return true;
	}



}
