package animals;

import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

import Olympics.Medal;
import graphics.CompetitionPanel;
import mobility.Point;

/**
 * class Cat to create a cat, it inherits from RerrestrialAnimal class
 * 
 * @author liron
 *
 */
public class Cat extends TerrestrialAnimals {
	/**
	 * boolean field that describe the castrated of the cat
	 */
	private boolean Castrated;// ��� ����� �����
//animal-individual-sound: Meow
	protected int meterMove=5;
	/**
	 * a default constructor- no parameters
	 */
	public Cat() {
		super();
		Castrated = true;
		this.setSound("Meow");
	}



	/**
	 * Constructor
	 * 
	 * @param name       - name of the cat object (String)
	 * @param g          -gender of the cat object (enum)
	 * @param weight     - weight of the cat object(double)
	 * @param speed      - speed of the cat object (double)
	 * @param A          -Medal's array of the cat object(Medal)
	 * @param position   -point of the cat object(Point)
	 * @param legs       -number of legs of the cat object (double)
	 * @param castrated- boolean value of the cat object(boolean)
	 * 
	 *                   call to the super class constructor
	 */
	public Cat(String name, animals.Animal.gender g, double weight, double speed, Medal[] A, Point position, int legs,
			boolean castrated, int maxEnergy, int energyMeter, int size) {
		super(name, g, weight, speed, A, position, legs, "Meow", maxEnergy, energyMeter, size);
		this.Castrated = castrated;
	}

	/**
	 * Constructor without point
	 * 
	 * @param name       - name of the cat object (String)
	 * @param g          -gender of the cat object (enum)
	 * @param weight     - weight of the cat object(double)
	 * @param speed      - speed of the cat object (double)
	 * @param A          -Medal's array of the cat object(Medal)
	 * @param legs       -number of legs of the cat object (double)
	 * @param castrated- boolean value of the cat object(boolean) call to the super
	 *                   class constructor
	 */
	public Cat(String name, gender g, double weight, double speed, Medal[] A, int legs, boolean castrated,
			int maxEnergy, int energyMeter, int size) {
		super(name, g, weight, speed, A, legs, "Meow", maxEnergy, energyMeter, size);
		this.Castrated = castrated;

     //BufferedImage Img1, BufferedImage Img2,BufferedImage Img3, BufferedImage Img4,Img1,Img2,Img3, Img4
		
	}

	/**
	 * boolean method return if the cat is castrated
	 * 
	 * @return Castrated (boolean value)
	 */
	public boolean isCastrated() {
		return Castrated;
	}

	/**
	 * boolean set method that change the cat's Castrated and return true after the
	 * change
	 * 
	 * @param castrated (boolean)
	 * @return boolean value
	 */
	public boolean setCastrated(boolean castrated) {
		Castrated = castrated;
		return true;
	}

	/**
	 * Overloaded method that return a string of the cat's details call to
	 * superclass toString
	 * 
	 * @return String
	 */
	public String toString() {
		return super.toString() + " is castrated: " + Castrated;
	}
	
	public String returnAnimal() {
		return "Cat";
	}
	



}
