package animals;

import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

import Olympics.Medal;
import animals.Dolphin.WaterType;
import graphics.CompetitionPanel;
import mobility.Point;

/**
 * class Snake to create a snake, it inherits from TerrestrialAnimals class and
 * implements IReptile interface
 * 
 * @author liron
 *
 */
public class Snake extends TerrestrialAnimals implements IReptile {
	/**
	 * A new enum type that call Poisonous
	 */
	public enum Poisonous {
		high, medium,low
	};// ������

	/**
	 * A Poisonous(enum) field that describe the poisonous of the snake
	 */
	private Poisonous Poisonous;

	/**
	 * A length field that describe length of the snake
	 */
	private double length;// ���� ����
	// animal-individual-sound: ssssssss


	

	/**
	 * Constructor
	 * 
	 * @param name      - name of the Snake object (String)
	 * @param g         -gender of the Snake object (enum)
	 * @param weight    - weight of the Snake object(double)
	 * @param speed     - speed of the Snake object (double)
	 * @param A         -Medal's array of the Snake object(Medal)
	 * @param position  -point of the Snake object(Point)
	 * @param legs      -number of legs of the Snake object (double)
	 * @param length-   the length of the Snake object (double)
	 * @param poisonous - the poisonous of the Snake object(enum)
	 * 
	 *                  call to the super class constructor
	 */
	public Snake(String name, animals.Animal.gender g, double weight, double speed, Medal[] A, Point position, int legs,
			Poisonous poisonous, double length,int maxEnergy,int energyMeter,int size) {
		super(name, g, weight, speed, A, position, legs, "ssssssss",maxEnergy,energyMeter,size);
		this.Poisonous = poisonous;
		this.setLength(length);

	}

	/**
	 * Constructor-without point
	 * 
	 * @param name      - name of the Snake object (String)
	 * @param g         -gender of the Snake object (enum)
	 * @param weight    - weight of the Snake object(double)
	 * @param speed     - speed of the Snake object (double)
	 * @param A         -Medal's array of the Snake object(Medal)
	 * @param legs      -number of legs of the Snake object (double)
	 * @param length-   the length of the Snake object (double)
	 * @param poisonous - the poisonous of the Snake object(enum)
	 * 
	 *                  call to the super class constructor
	 */
	public Snake(String name, animals.Animal.gender g, double weight, double speed, Medal[] A, int legs,
			Poisonous poisonous, double length,int maxEnergy,int energyMeter,int size) {
		super(name, g, weight, speed, A, legs, "ssssssss",maxEnergy,energyMeter,size);
		this.Poisonous = poisonous;
		this.setLength(length);
	}

	/**
	 * a default constructor- no parameters
	 */
	public Snake() {
		super();
		this.Poisonous = Poisonous.high;
		this.setLength(10);
		this.setSound("ssssssss");
	}

	/**
	 * Method that return the Poisonous field
	 * 
	 * @return Poisonous (Poisonous)
	 */
	public Poisonous getPoisonous() {
		return Poisonous;
	}

	/**
	 * boolean set method that change the Snake's poisonous,return true after the
	 * change
	 * 
	 * @param poisonous - if the snake is poisonous
	 * @return boolean value
	 */
	public boolean setPoisonous(Poisonous poisonous) {
		this.Poisonous = poisonous;
		return true;
	}

	/**
	 * Method that return the length field
	 * 
	 * @return length (double)
	 */
	public double getLength() {
		return length;
	}

	/**
	 * boolean set method that change the Snake's length,return true after the
	 * change
	 * 
	 * @param length is the length of the snake
	 * @return boolean value
	 */
	public boolean setLength(double length) {
		if (length <= 0) {
			System.out.println("invaild value");
			return false;
		} else {
			this.length = length;
			return true;
		}
	}

	/**
	 * Method that change the Snake's speed and check if it more than the max
	 * 
	 * @param newSpeed is the speed of the snake
	 * @return MAX_SPEED,newSpeed
	 */
	public int speedUp(int newSpeed) {
		if (newSpeed > MAX_SPEED) {
			this.setSpeed(MAX_SPEED);
			return MAX_SPEED;
		} else {
			this.setSpeed(newSpeed);
			return newSpeed;
		}
	}

	/**
	 * Overloaded method that return a string of the Snake's details call to
	 * superclass toString
	 * 
	 * @return String
	 */
	public String toString() {
		return super.toString() + " is position:" + Poisonous + " the legnth:" + length;
	}
	
	public void drawObject(Graphics g) {
		g.drawImage(Img1, getLocation().getX(), getLocation().getY(), size, size, pan);
	}
	
	public String returnAnimal() {
		return "Snake";
	}

}
