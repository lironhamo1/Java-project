package animals;

import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

import Olympics.Medal;
import animals.Animal.Orientation;
import graphics.CompetitionPanel;
import mobility.Point;

/**
 * class Eagle to create an eagle, it inherits from AirAnimal class
 * 
 * @author liron
 *
 */
public class Eagle extends AirAnimal {// ���

	/**
	 * A double field that describe the altitude Of flight of the Eagle
	 */
	private double altitudeOfFlight;
	/**
	 * A double field that fant changed that describe the max altitude Of flight of
	 * the Eagle
	 */
	private static final int MAX_ALTITUDE = 1000;

	// animal-individual-sound: Clack-wack-chack

	/**
	 * a default constructor- no parameters
	 */
	public Eagle() {
		super();
		this.altitudeOfFlight = 100;
		this.setSound("Clack-wack-chack");
	}

	/**
	 * Constructor
	 * 
	 * @param name             - name of the Eagle object (String)
	 * @param g                -gender of the Eagle object (enum)
	 * @param weight           - weight of the Eagle object(double)
	 * @param speed            - speed of the Eagle object (double)
	 * @param A                -Medal's array of the Eagle object(Medal)
	 * @param position         -point of the Eagle object(Point)
	 * @param wings            -wingspan of the Eagle object (double)
	 * @param altitudeOfFlight -the altitude Of flight of the Eagle object(double)
	 * 
	 *                         call to the super class constructor
	 */
	public Eagle(String name, animals.Animal.gender g, double weight, double speed, Medal[] A, Point position,
			double wings, double altitudeOfFlight, int maxEnergy, int energyMeter, int size) {
		super(name, g, weight, speed, A, position, wings, "Clack-wack-chack", maxEnergy, energyMeter, size);
		setAltitudeOfFlight(altitudeOfFlight);
	}

	/**
	 * Constructor-without point
	 * 
	 * @param name             - name of the Eagle object (String)
	 * @param g                -gender of the Eagle object (enum)
	 * @param weight           - weight of the Eagle object(double)
	 * @param speed            - speed of the Eagle object (double)
	 * @param A                -Medal's array of the Eagle object(Medal)
	 * @param wings            -wingspan of the Eagle object (double)
	 * @param altitudeOfFlight -the altitude Of flight of the Eagle object(double)
	 * 
	 *                         call to the super class constructor
	 */
	public Eagle(String name, animals.Animal.gender g, double weight, double speed, Medal[] A, double wings,
			double altitudeOfFlight, int maxEnergy, int energyMeter, int size) {
		super(name, g, weight, speed, A, wings, "Clack-wack-chack", maxEnergy, energyMeter, size);
		setAltitudeOfFlight(altitudeOfFlight);
	}

	/**
	 * Method that return the Altitude Of flight field
	 * 
	 * @return altitudeOfFlight(double)
	 */
	public double getAltitudeOfFlight() {
		return altitudeOfFlight;
	}

	/**
	 * ** boolean Set method to change AltitudeOfFlight- return true after the
	 * change
	 * 
	 * @param altitudeOfFlight1 double
	 * @return boolean value
	 */
	public boolean setAltitudeOfFlight(double altitudeOfFlight1) {
		if (altitudeOfFlight1 <= 0) {
			System.out.println("invaild value");
			return false;
		} else if (altitudeOfFlight1 > MAX_ALTITUDE) {
			this.altitudeOfFlight = MAX_ALTITUDE;
		} else {
			this.altitudeOfFlight = altitudeOfFlight1;
		}
		return true;
	}

	/**
	 * Overloaded method that return a string of the Eagle's details call to
	 * superclass toString
	 * 
	 * @return String
	 */
	public String toString() {
		return super.toString() + " altitude of flight:" + altitudeOfFlight;
	}

	/*public void drawObject(Graphics g) {
		if (orientation == Orientation.EAST) // animal move to the east side
			g.drawImage(Img1, getLocation().getX(), getLocation().getY() - size / 10, size * 2, size, pan);
		else if (orientation == Orientation.SOUTH) // animal move to the south side
			g.drawImage(Img2, getLocation().getX(), getLocation().getY() - size / 10, size, size, pan);
		else {
			g.drawImage(Img1, getLocation().getX(), getLocation().getY(), size, size, pan);
		}
	}*/
	public void loadImages(String nm) {
		try {
			System.out.println(nm);
			Img1 = ImageIO.read(new File("src/graphics/picture/"+nm+"E.png"));
			//System.out.println("load image1");
		} catch (IOException e) {
			System.out.println("cant load image1");
			this.Img1 = null;
		}
	}
	
	public String returnAnimal() {
		return "Eagle";
	}

}
