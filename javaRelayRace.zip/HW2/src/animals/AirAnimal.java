package animals;

import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

import Olympics.Medal;
import graphics.CompetitionPanel;
import mobility.*;

/**
 * class AirAnimal to create a animal that live in the air, inherits from Animal
 * class
 * 
 * @author liron
 *
 */
public class AirAnimal extends Animal {
	/**
	 * double field of air animal's wingspan
	 */
	private double wingspan;// ���� ������

	/**
	 * a default constructor- no parameters
	 */
	public AirAnimal() {// Ctor
		super();
		this.setWingspan(10);
	}

	/**
	 * Constructor
	 * 
	 * @param name   - name of the AirAnimal object (String)
	 * @param gender -gender of the AirAnimal object (enum)
	 * @param weight - weight of the AirAnimal object(double)
	 * @param speed  - speed of the AirAnimal object (double)
	 * @param A      -Medal's array of the AirAnimal object(Medal)
	 * @param point  -point of the AirAnimal object(Point)
	 * @param wings- wingspan of the AirAnimal object(double)
	 * @param sound- the sound that the animal make(String)
	 */
	public AirAnimal(String name, gender gender, double weight, double speed, Medal A[], Point point, double wings,
			String sound, int maxEnergy, int energyMeter, int size) {
		super(name, gender, weight, speed, A, point, sound, maxEnergy, energyMeter, size);
		this.setWingspan(wings);
	}

	/**
	 * Constructor without point- there is default Point's values
	 * 
	 * @param name   - name of the AirAnimal object (String)
	 * @param g      -gender of the AirAnimal object (enum)
	 * @param weight - weight of the AirAnimal object(double)
	 * @param speed  - speed of the AirAnimal object (double)
	 * @param A      -Medal's array of the AirAnimal object(Medal)
	 * @param wings- wingspan of the AirAnimal object(double)
	 * @param sound- the sound that the animal make(String)
	 */
	public AirAnimal(String name, gender g, double weight, double speed, Medal A[], double wings, String sound,
			int maxEnergy, int energyMeter, int size) {
		super(name, g, weight, speed, A, new Point(0, 100), sound, maxEnergy, energyMeter, size);
		this.setWingspan(wings);
	}

	/**
	 * Method that return the wingspan
	 * 
	 * @return wingspan(double)
	 */
	public double getWingspan() {
		return wingspan;
	}

	/**
	 * boolean Set method to change wingspan- return true after the change
	 * 
	 * @param wingspan (double)
	 * @return boolean value
	 */
	public boolean setWingspan(double wingspan) {
		this.wingspan = wingspan;
		return true;
	}

	/**
	 * Overloaded method that return a string of the air animal's details call to
	 * superclass toString
	 * 
	 * @return String
	 */
	public String toString() {
		return super.toString() + "wingspan:" + wingspan;
	}
	
	public String returnType() {
		return "Air";
	}
	
	public void loadImages(String nm) {
		try {
			Img1 = ImageIO.read(new File("src\\graphics\\picture\\" + nm + "E.png"));
			System.out.println("load image1");
		} catch (IOException e) {
			System.out.println("cant load image1");
			this.Img1 = null;
		}
	}

	/*public void drawObject(Graphics g) {
		g.drawImage(Img1, getLocation().getX(), getLocation().getY(), size, size,pan);
	}*/

	@Override
	public String returnAnimal() {

		return null;
	}


}
