package animals;

import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

import Olympics.Medal;
import animals.Animal.Orientation;
import graphics.CompetitionPanel;
import mobility.Point;

/**
 * class Alligator to create an alligator, it inherits from WaterAnimal class
 * and implements IReptile interface
 * 
 * @author liron
 *
 */
public class Alligator extends WaterAnimal implements IReptile {// ����
	/**
	 * String field of the Alligator- it area of living
	 */
	private String AreaOfLiving;
	private TerrestrialAnimals terrestrialAnimals;

	/**
	 * a default constructor- no parameters
	 */
	public Alligator() {
		super();
		this.AreaOfLiving = "Miami";
		this.setSound("Roar");
	}

	/**
	 * Constructor
	 * 
	 * @param name     - name of the Alligator object (String)
	 * @param g        -gender of the Alligator object (enum)
	 * @param weight   - weight of the Alligator object(double)
	 * @param speed    - speed of the Alligator object (double)
	 * @param A        -Medal's array of the Alligator object(Medal)
	 * @param position -point of the Alligator object(Point)
	 * @param dive-    divedept of the Alligator object(double)
	 * @param living-  the area living of the Alligator object(String) the
	 *                 constructor call to the super classes to initialize the
	 *                 object
	 */
	// legs
	public Alligator(String name, animals.Animal.gender g, double weight, double speed, Medal[] A, Point position,
			double dive, String living, int legs, int maxEnergy, int energyMeter, int size) {
		super(name, g, weight, speed, A, position, dive, "Roar", maxEnergy, energyMeter, size);
		terrestrialAnimals = new TerrestrialAnimals(name, g, weight, speed, A, position, legs, "Roar", maxEnergy,
				energyMeter, size);
		this.AreaOfLiving = living;

	}

	/**
	 * Constructor without point
	 * 
	 * @param name    - name of the Alligator object (String)
	 * @param g       -gender of the Alligator object (enum)
	 * @param weight  - weight of the Alligator object(double)
	 * @param speed   - speed of the Alligator object (double)
	 * @param A       -Medal's array of the Alligator object(Medal)
	 * @param dive-   divedept of the Alligator object(double)
	 * @param living- the area living of the Alligator object(String) the
	 *                constructor call to the super classes to initialize the object
	 */
	// legs

	public Alligator(String name, animals.Animal.gender g, double weight, double speed, Medal[] A, double dive,
			String living, int legs, int maxEnergy, int EnergyForMeter, int size) {
		super(name, g, weight, speed, A, dive, "Roar", maxEnergy, EnergyForMeter, size);
		terrestrialAnimals = new TerrestrialAnimals(name, g, weight, speed, A, legs, "Roar", maxEnergy, EnergyForMeter,
				size);
		this.AreaOfLiving = living;
		}

	/**
	 * Method that return the AreaOfLiving field
	 * 
	 * @return AreaOfLiving(String)
	 */
	public String getAreaOfLiving() {
		return AreaOfLiving;
	}

	/**
	 * boolean Set method to change AreaOfLiving- return true after the change
	 * 
	 * @param areaOfLiving string
	 * @return boolean value
	 */
	public boolean setAreaOfLiving(String areaOfLiving) {
		AreaOfLiving = areaOfLiving;
		return true;
	}

	/**
	 * method to change the speed- check if it valid
	 * 
	 * @param new_speed (int)
	 * @return new_speed,MAX_SPEED
	 */
	public int speedUp(int new_speed) {
		if (new_speed > MAX_SPEED) {
			this.setSpeed(MAX_SPEED);
			return MAX_SPEED;
		} else {
			this.setSpeed(new_speed);
			return new_speed;
		}
	}

	/**
	 * Overloaded method that return a string of the Alligator's details call to
	 * superclass toString
	 * 
	 * @return String
	 */
	public String toString() {
		return super.toString() + "area of live:" + AreaOfLiving;
	}

	public String returnAnimal() {
		return "Alligator";
	}

	public void drawObject(Graphics g) {
		if (orientation == Orientation.EAST) // animal move to the east side
			g.drawImage(Img1, getLocation().getX(), getLocation().getY() - size / 10, size * 2, size, pan);
		else if (orientation == Orientation.SOUTH) // animal move to the south side
			g.drawImage(Img2, getLocation().getX(), getLocation().getY() - size / 10, size, size, pan);
		else {
			g.drawImage(Img1, getLocation().getX(), getLocation().getY(), size, size, pan);		}
	}

}
