package animals;
/**
 * An interface of reptile
 * @author liron
 *
 */
public interface IReptile {
	/**
	 * static final field of the max speed of the reptile
	 */
	public static final int MAX_SPEED = 5;
	/**
	 * method that update the speed of the reptile, must be under the MAX_SPEED field. 
	 * @param x the new speed.
	 * @return new speed.
	 */
	public int speedUp(int x); //must be under MAX_SPEED
}
