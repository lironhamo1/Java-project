package animals;

import mobility.*;

import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.Arrays;

import javax.imageio.ImageIO;

import Olympics.*;
import animals.Animal.Orientation;
import animals.Snake.Poisonous;
import graphics.CompetitionPanel;
import graphics.IAnimal;
import graphics.IDrawable;

/**
 * An abstract class, its a superclass for many inherits classes, and gives
 * tools to create an Animal object
 * 
 * @author liron
 *
 */
public abstract class Animal extends Mobile implements IAnimal, IDrawable, Cloneable {
	/**
	 * A new enum type that call gender
	 */
	public enum gender {
		Male, Female, Hermaphrodite
	};

	/**
	 * A string field that describe the name of the animal
	 */
	private String name;
	/**
	 * A gender(enum) field that describe the gender of the animal
	 */
	private gender gender;
	/**
	 * A double field that describe the weight of the animal
	 */
	private double weight;
	/**
	 * A double field that describe the speed of the animal
	 */
	private double speed;
	/**
	 * A Medal field that describe the medals array of the animal
	 */
	private Medal medals[];
	/**
	 * A string field that describe the sound of the animal
	 */

	private String sound;
	protected int size;
	protected int maxEnergy;
	protected int energyPerMeter;
	protected CompetitionPanel pan = CompetitionPanel.getCompetitionPanel();
	protected int meterMove = 5;

	public enum Orientation {
		NORTH, SOUTH, EAST, WEST
	};

	
	protected Orientation orientation;
	protected BufferedImage Img1;
	protected BufferedImage Img2;
	protected BufferedImage Img3;
	protected BufferedImage Img4;
	public final static String PICTURE_PATH = "src/graphics/pictures/";
	protected int energyNow;
	protected int ConsumptionEnergy = 0;

	/**
	 * a default constructor- no parameters
	 */
	public Animal() {
		super(new Point(0, 0));
		this.setName("liron");
		this.setGender(gender.Female);
		this.setWeight(50);
		this.setSpeed(12);
		this.medals = new Medal[1];
		for (int i = 0; i < 1; i++) {
			medals[i] = new Medal();
		}
		this.sound = "silent";
		maxEnergy = 10;
		energyPerMeter = 2;
		this.loadImages(name);
		energyNow = maxEnergy;
		orientation = orientation.EAST;
	}

	/**
	 * Constructor
	 * 
	 * @param name     - name of the Animal object (String)
	 * @param g        -gender of the Animal object (enum)
	 * @param weight   - weight of the Animal object(double)
	 * @param speed    - speed of the Animal object (double)
	 * @param A        -Medal's array of the Animal object(Medal)
	 * @param position -point of the Animal object(Point)
	 * @param sound-   the sound that the animal make(String)
	 */
	public Animal(String name, gender g, double weight, double speed, Medal A[], Point position, String sound,
			int maxEnergy, int EnergyForMeter, int size) {
		super(position);
		this.sound = sound;
		this.setName(name);
		this.setGender(g);
		this.setWeight(weight);
		this.setSpeed(speed);
		this.medals = new Medal[A.length];
		this.maxEnergy = maxEnergy;
		this.energyPerMeter = EnergyForMeter;
		// this.pan = pan;
		for (int i = 0; i < A.length; i++) {
			medals[i] = A[i];
		}
		this.size = size;
		this.loadImages(name);
		energyNow = maxEnergy;

	}

	/**
	 * a method that can't be overloaded it identify the type of the object and
	 * print on the screen perspectively the sound of the animal
	 * 
	 * @see String
	 */
	public final void makeSound() {
		System.out.println("Animal " + this.getName() + " said " + this.getSound());
	}

	/**
	 * Method that return the name field
	 * 
	 * @return name(String)
	 */
	public String getName() {
		return name;
	}

	/**
	 * boolean set method that change the animal's name and return true after that
	 * 
	 * @param name (String)
	 * @return boolean value
	 */
	public boolean setName(String name) {
		this.name = name;
		return true;
	}

	/**
	 * Method that return the gender field
	 * 
	 * @return gender(gender type)
	 */
	public gender getGender() {
		return gender;
	}

	/**
	 * boolean set method that change the animal's gender,return true after the
	 * change
	 * 
	 * @param Gender (gender type)
	 * @return boolean value
	 */
	public boolean setGender(gender Gender) {
		gender = Gender;
		return true;

	}

	/**
	 * Method that return the weight field
	 * 
	 * @return weight(double)
	 */
	public double getWeight() {
		return weight;
	}

	/**
	 * boolean set method that change the animal's weight
	 * 
	 * @param weight (double)
	 * @return boolean value
	 */
	public boolean setWeight(double weight) {
		this.weight = weight;
		return true;
	}

	/**
	 * Method that return the speed field
	 * 
	 * @return speed(double)
	 */
	public double getSpeed() {
		return speed;
	}

	/**
	 * boolean set method that change the animal's speed
	 * 
	 * @param speed (double)
	 * @return boolean value
	 */
	public boolean setSpeed(double speed) {
		if (speed >= 0) {
			this.speed = speed;
			return true;
		} else {
			System.out.println("invaild value speed");
			return false;
		}
	}

	/**
	 * Overloaded method that return a string of the Animal's details
	 * 
	 * @return String
	 */
	public String toString() {
		return name + " " + gender + " " + speed + " " + weight + " " + Arrays.toString(medals) + " "
				+ this.getLocation() + " ";
	}

	/**
	 * Method that return the sound of the animal
	 * 
	 * @return sound(String)
	 */
	public String getSound() {
		return sound;
	}

	/**
	 * boolean set method that change the animal's sound
	 * 
	 * @param sound (String)
	 * @return boolean value
	 */
	public boolean setSound(String sound) {
		this.sound = sound;
		return true;

	}

	public int getMaxEnergy() {
		return maxEnergy;
	}

	public void setMaxEnergy(int maxEnergy) {
		this.maxEnergy = maxEnergy;
	}

	public int getEnergyPerMeter() {
		return energyPerMeter;
	}

	public void setEnergyPerMeter(int energyPerMeter) {
		this.energyPerMeter = energyPerMeter;
	}

	public int energyChange(int meter) {// energy changed per meter
		energyNow = energyNow - (meter * energyPerMeter);
		if (energyNow > 0) {
			setLocation(new Point(getLocation().getX() + meter, getLocation().getY()));
		}
		return maxEnergy;
	}

	public boolean eat(int food) {
		if (food <= 0) {
			return false;
		}
		if (this.energyNow - this.energyPerMeter >= 0) {
			if (this.energyNow + food >= this.maxEnergy) {
				this.energyNow = this.maxEnergy;
				this.energyNow = this.energyNow - this.energyPerMeter;
				this.setLocation(new Point(this.getLocation().getX() + this.energyPerMeter, this.getLocation().getY()));
			} else {
				this.energyNow = this.energyNow + food;//
				this.energyNow = this.energyNow - this.energyPerMeter;//
				this.setLocation(new Point(this.getLocation().getX() + this.energyPerMeter, this.getLocation().getY()));
			}
			this.totalDistance += this.energyPerMeter;
		}
		return true;

	}

	public int getConsumptionEnergy() {
		return ConsumptionEnergy;
	}

	public int getEnergyNow() {
		return energyNow;
	}

	public abstract String returnType();

	public abstract String returnAnimal();

	public void loadImages(String nm) {
		try {
			Img1 = ImageIO.read(new File("src\\graphics\\picture\\" + nm + "E.png"));
			//System.out.println("load image1");
		} catch (IOException e) {
			System.out.println("cant load image1");
			this.Img1 = null;
		}
	}

	public void drawObject(Graphics g) {
		if (orientation == Orientation.EAST) // animal move to the east side
			g.drawImage(Img1, getLocation().getX(), getLocation().getY() - size / 10, size * 2, size, pan);
		else if (orientation == Orientation.SOUTH) // animal move to the south side
			g.drawImage(Img2, getLocation().getX(), getLocation().getY() - size / 10, size, size, pan);
		else if (orientation == Orientation.WEST) // animal move to the west side
			g.drawImage(Img3, getLocation().getX(), getLocation().getY() - size / 10, size * 2, size, pan);
		else if (orientation == Orientation.NORTH) // animal move to the north side
			g.drawImage(Img4, getLocation().getX() - size / 2, getLocation().getY() - size / 10, size, size * 2, pan);
		else {
			g.drawImage(Img1, getLocation().getX(), getLocation().getY(), size, size, pan);
		}
	}
	public void setorien(Orientation south) {
		this.orientation = south;
	}

}
