package animals;

import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

import Olympics.Medal;
import graphics.CompetitionPanel;
import mobility.Point;
/**
 * class Dog to create a dog, it inherits from TerrestrialAnimal class
 * 
 * @author liron
 *
 */
public class Dog extends TerrestrialAnimals {
	/**
	 * string field of the dog's breed
	 */
	private String breed;// (���)
	// animal-individual-sound: Woof Woof

	/**
	 * a default constructor- no parameters
	 */
	public Dog() {
		super();
		this.breed = "German shepherd";
		this.setSound("Woof Woof");
	}

	
	/**
	 * Constructor
	 * 
	 * @param name   - name of the Dog object (String)
	 * @param g -gender of the Dog object (enum)
	 * @param weight - weight of the Dog object(double)
	 * @param speed  - speed of the Dog object (double)
	 * @param A      -Medal's array of the Dog object(Medal)
	 * @param legs   -number of legs of the Dog object (double)
	 * @param breed  -the breed name of the Dog object(String)
	 * @param position  -point of the Dog object(Point) call to the super class
	 *               constructor
	 */
	public Dog(String name, animals.Animal.gender g, double weight, double speed, Medal[] A, Point position, int legs,
			String breed,int maxEnergy,int energyMeter,int size) {
		super(name, g, weight, speed, A, position, legs,"Woof Woof",maxEnergy,energyMeter,size);
		this.breed = breed;
		
	}

	/**
	 * Constructor- without point
	 * 
	 * @param name   - name of the Dog object (String)
	 * @param g -gender of the Dog object (enum)
	 * @param weight - weight of the Dog object(double)
	 * @param speed  - speed of the Dog object (double)
	 * @param A      -Medal's array of the Dog object(Medal)
	 * @param legs   -number of legs of the Dog object (double)
	 * @param breed  -the breed name of the Dog object(String) call to the super
	 *               class constructor
	 */
	public Dog(String name, animals.Animal.gender g, double weight, double speed, Medal[] A, int legs, String breed,int maxEnergy,int energyMeter,int size) {
		super(name, g, weight, speed, A, legs," Woof Woof",maxEnergy,energyMeter,size);
		this.breed = breed;
	}

	/**
	 * Method that return the breed field
	 * 
	 * @return breed(String)
	 */
	public String getBreed() {
		return breed;
	}


	/**
	 * boolean Set method to change breed- return true after the change
	 * @param breed string
	 * @return boolean value
	 */
	public boolean setBreed(String breed) {
		this.breed = breed;
		return true;
	}
	/**
	 * Overloaded method that return a string of the dog's details
	 * call to superclass toString
	 * @return String
	 */
	public String toString() {
		return super.toString() + " breed: " + breed;
	}
	public String returnAnimal() {
		return "Dog";
	}
}
