package competitions;

import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.concurrent.atomic.AtomicBoolean;

import animals.Animal;
import mobility.Point;
import threads.AnimalThread;

public class CourierTournament extends Tournament {
	protected Animal[][] array;

	public CourierTournament(Animal[][] Darray) {
		super("Courier", Darray);
		array = Darray;
	}

	@Override
	protected void setup(Animal[][] array) {

		AtomicBoolean startFlag = new AtomicBoolean(false);
		Scores scores = new Scores();
		Point[] p;
		int dis;
		int j = 0, i = 0;
		for (i = 0; i < array.length; i++) {
			AtomicBoolean[] Flags = new AtomicBoolean[array[i].length];
			for (j = 0; j < array[i].length; j++) {
				Flags[j] = new AtomicBoolean(false);
			}
			if (array[i][0].returnType() == "Land") {
				System.out.println(array[i].length);
				p = locationPointLand(array[i].length);
				setlocationLand(p, array[i]);
				dis = 1960;
			} else {
				p = locationPoint(array[i].length, 580);
				dis = 580;
				setlocation(p, array[i]);
			}

			for (j = 0; j < array[i].length; j++) {
				int neededDistance = dis / array[i].length;
				if (j != 0) {
					AnimalThread animal = new AnimalThread(array[i][j], Flags[j - 1], Flags[j], neededDistance);
					Thread a = new Thread(animal);
					a.start();
				} else {
					AnimalThread animal = new AnimalThread(array[i][j], startFlag, Flags[j], neededDistance);
					Thread a = new Thread(animal);
					a.start();
				}
			}
			j--;
			Referee referee = new Referee(Integer.toString(i), scores, Flags[j]);
			Thread r=new Thread(referee);
			r.start();
		}
		this.tournamentThread = new TournamentThread(scores, i, startFlag);
		Thread a = new Thread(tournamentThread);
		a.start();
	}

	public Point[] locationPoint(int n, int distanc) {
		Point[] a = new Point[n];
		int size = distanc / n;
		for (int i = 0; i < n; i++) {
			a[i] = new Point(i * size, 0);

		}
		return a;
	}

	public Point[] locationPointLand(int n) {
		System.out.println(n + "llll");
		Point[] a = new Point[n];
		switch (n) {
		case 1:
			a[0] = new Point(0, 400);
			break;
		case 2:
			a[0] = new Point(0, 400);
			a[1] = new Point(580, 0);
			break;
		case 3:
			a[0] = new Point(0, 400);
			a[1] = new Point(580, 327);
			a[2] = new Point(254, 0);
			break;
		}
		return a;

	}

	public void setlocationLand(Point[] p, Animal[] a) {
		for (int i = 0; i < p.length; i++) {
			a[i].setLocation(p[i]);
		}
	}

	public void setlocation(Point[] p, Animal[] a) {
		int y = a[0].getLocation().getY();
		for (int i = 0; i < p.length; i++) {
			a[i].setLocation(new Point(p[i].getX(), y));
		}
	}
}
