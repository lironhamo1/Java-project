package competitions;

import java.util.ArrayList;
import java.util.Date;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;

import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;

import graphics.CompetitionPanel;

public class TournamentThread implements Runnable {
	Scores scores;// ����� �� ������� ������� �� �� �����
	AtomicBoolean startSignal;// ��� ����� ������ �� �� �����
	int groups; // ���� ������� �������
	JPanel panelX = CompetitionPanel.getCompetitionPanel();
	JPanel panel = new JPanel();
	String[] titelsJT = { "Number of Team", "Date" };
	Map<String, Date> map;
	Object[][] dataJT;

	public TournamentThread(Scores s, int Group, AtomicBoolean startFlag) {
		scores = s;
		groups = Group;
		startSignal = startFlag;
		dataJT = new Object[groups][2];

	}

	public ArrayList<String> keyToArray() {
		ArrayList<String> keys = new ArrayList<String>();
		for (String key : map.keySet()) {
			keys.add(key);
		}
		return keys;
	}

	public void run() {
		synchronized (startSignal) {
			startSignal.set(true);
			startSignal.notifyAll();
		}
		int j = 0;
		while (j < groups) {
			synchronized (scores) {
				try {
					scores.wait();
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
			map = scores.getAll();
			for (int i = 0; i < map.size(); i++) {
				JTable(i);
			}
			j++;
		}

		// System.out.println(map.size() + map.toString());
		System.out.println("map size" + map.size());

		JTable jtableInfo = new JTable(dataJT, titelsJT);
		jtableInfo.setFillsViewportHeight(true);
		jtableInfo.setEnabled(false);
		panel.add(new JScrollPane(jtableInfo));
		JOptionPane.showMessageDialog(null, panel, "Information Competition", JOptionPane.INFORMATION_MESSAGE);
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		panelX.add(panel);
		panel.setVisible(true);
		panelX.setVisible(true);

	}

	public void JTable(int i) {
		ArrayList<String> key = keyToArray();
		key = keyToArray();
		dataJT[i][0] = key.get(i);
		System.out.println(key.get(i));
		System.out.println(map.get(key.get(i)));
		dataJT[i][1] = map.get(key.get(i));
	}
}
