package competitions;

import java.util.concurrent.atomic.AtomicBoolean;

import animals.Animal;
import threads.AnimalThread;

public class RegularTournament extends Tournament {
	protected Animal[][] array;

	public RegularTournament(Animal[][] Darray) {
		super("Regular", Darray);
		array = Darray;

	}

	@Override
	protected void setup(Animal[][] array) {
		AtomicBoolean startFlag = new AtomicBoolean(false);
		// new AtomicBoolean(true);
		Scores scores = new Scores();
		for (int j = 0; j < array[0].length; j++) {
			AtomicBoolean finishflag = new AtomicBoolean(false);
			AnimalThread animal = new AnimalThread(array[0][j], startFlag, finishflag);
			Thread a = new Thread(animal);
			a.start();
			Referee referee = new Referee(array[0][j].getName(), scores, finishflag);
			Thread r = new Thread(referee);
			r.start();
		}
		this.tournamentThread = new TournamentThread(scores, array[0].length, startFlag);
		Thread a = new Thread(tournamentThread);
		a.start();
	}

}
