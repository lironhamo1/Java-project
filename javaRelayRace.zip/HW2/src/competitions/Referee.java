package competitions;

import java.util.concurrent.atomic.AtomicBoolean;

public class Referee implements Runnable {
	AtomicBoolean flag;
	String name;
	Scores scores;

	/**
	 *  
	 * @param name name of the grope or animal
	 * @param secores
	 * @param flag
	 */
	Referee(String name, Scores secores, AtomicBoolean flag) {
		this.flag = flag;
		this.name = name;
		scores = secores;
	}
	@Override
	public void run() {
		while (flag.get() == false) {
			synchronized (flag) {
				try {
					flag.wait();
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		}
		scores.add(name);
		System.out.println(name);
		synchronized (scores) {
			scores.notify();
		}
	}

}
