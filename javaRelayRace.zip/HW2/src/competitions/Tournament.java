package competitions;

import java.util.concurrent.atomic.AtomicBoolean;

import animals.Animal;

public abstract class Tournament {
	
	protected TournamentThread tournamentThread; 
	private String nameComp; //Courier or Regular
	//private AtomicBoolean startFlag;
	
	
	Tournament(String name,Animal[][] Darray){
		setup(Darray);
		nameComp=name;
		//this.startFlag=startFlag;
	}

	protected abstract void setup(Animal[][] array) ;
	
	public TournamentThread getTournamentThread() {
		return tournamentThread;
	}
	
	public String getNameComp() {
		return nameComp;
	}

}
