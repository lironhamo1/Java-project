package mobility;

public abstract class Mobile implements ILocatable {
	/**
	 * field of the location(type Point)
	 */
	private Point location;
	/**
	 * field of the total distance(double)
	 */
	protected Double totalDistance=0.0;

	/**
	 * Constructor call the Constructor of Point
	 * 
	 * @param loc (other Point)
	 */
	public Mobile(Point loc) {// constructor
		this.location = new Point(loc.getX(), loc.getY());
	}

	/**
	 * default Constructor
	 */
	public Mobile() {// constructor default
		this.location = new Point(0, 0);
	}

	/**
	 * Method that return the location field
	 * 
	 * @return location (Point)
	 */
	public Point getLocation() {// ILocation
		return location;
	}

	/**
	 * boolean set method that change the locatoin, return true if successful and
	 * false if not
	 * 
	 * @param p(Point)
	 * @return boolean value
	 */
	public boolean setLocation(Point p) { // ILocation
		if (this.location.setX(p.getX()) && this.location.setY(p.getY())) {
			//System.out.println("the location has changed");
			return true;
		} else {
			System.out.println("the location has no changed");
			return false;
		}
	}

	/**
	 * method that change the total distance after a move
	 * 
	 * @param x (the new move)
	 * @see String of total disatance
	 */
	public void addTotalDistance(double x) {
		this.totalDistance += x;
		System.out.println("the td after movement is " + totalDistance);
	}

	/**
	 * method that calculate the distance from a point
	 * 
	 * @param p (Point)
	 * @return theDistance
	 */
	public double calcDistance(Point p) {// d between the object to the point
		double theDistance;
		theDistance = Math.sqrt((location.getY() - p.getY()) * (location.getY() - p.getY())
				+ (location.getX() - p.getX()) * (location.getX() - p.getX()));
		return theDistance;
	}

	/**
	 * method that calculate the distance from the current point to the parameter
	 * point
	 * 
	 * @param p (other Point)
	 * @return distance,0
	 */
	public double move(Point p) {
		double distance = calcDistance(p);
		setLocation(p);
		if (distance == 0)
			return 0;
		else
			return distance;
	}

	/**
	 * Overloaded method that return a string of the Mobile object's details
	 * 
	 * @return String
	 */
	public String toString() {
		return location + " and the total distance: " + totalDistance + " ";

	}
	public double getTotalDistance() {
		return totalDistance;
		
	}
	
	public void setTotalDistance(double a) {
		totalDistance+=a;
	}
	

}
