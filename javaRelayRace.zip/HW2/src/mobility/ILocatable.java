package mobility;
import mobility.Point;


public interface ILocatable{
	/**
	 *method that return a location's point of the object.  
	 *@return location
	 */
	public Point getLocation();//return Point
	/**
	 * boolean method that update the location of the object- return true after the change. 
	 * @param p -a new point(Point)
	 * @return boolean value
	 */
	public boolean setLocation(Point p);
}
