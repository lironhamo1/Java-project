package mobility;

public class Point implements Cloneable{
	/**
	 * x field of the point
	 */
	private int x;
	/**
	 * y field of the point
	 */
	private int y;

	/**
	 * Constructor
	 * @param x of point
	 * @param y of point
	 */
	public Point(int x, int y) {
		this.x = x;
		this.y = y;
	}
	
	/**
	 * default constructor
	 */
	public Point() {
		this.x = 0;
		this.y = 0;
	}

	/**
	 * boolean set method that change the x value of the point, true if successes, false if not
	 * @param x of point
	 * @return boolean value
	 */
	public boolean setX(int x) {
		if (x >= 0) {
			this.x = x;
			//System.out.println("the value x has changed");
			return true;
		} else {
			System.out.println("the value is invalid");
			return false;
		}
	}
	/**
	 * boolean set method that change the y value of the point, true if successes, false if not
	 * @param y of point
	 * @return boolean value
	 */
	public boolean setY(int y) {
		if (y >= 0) {
			this.y = y;
			//System.out.println("the value y has changed");
			return true;
		} else
			System.out.println("the value is invalid");
		return false;
	}

	/**
	 * method that return the x field of the Point object
	 * @return x
	 */
	public int getX() {return x;}
	/**
	 * method that return the x field of the Point object
	 * @return y
	 */
	public int getY(){return y;}
	
	/**
	 * Overloaded method that return a string of the Point object's details
	 * 
	 * @return String
	 */
	public String toString() {
		return "The point: x=" + x + " y="+y; 
		
		
	}

}
