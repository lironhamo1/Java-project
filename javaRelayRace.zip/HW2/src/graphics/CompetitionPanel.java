package graphics;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.Vector;

import javax.imageio.ImageIO;
import javax.swing.AbstractAction;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

import org.w3c.dom.events.MouseEvent;

import animals.Animal;
import graphics.CompetitionFrame;

/**
 * Class CompetitionPanel- the panel of the competition, extend JPanel and
 * implement ActionListener
 * 
 * @author Liron hamo and Daniel Assayag
 *
 */

public class CompetitionPanel extends JPanel implements ActionListener {
	/**
	 * static CompetitionPanel object
	 */
	private static CompetitionPanel ObjComPanel;
	/**
	 * static Vector of animals in the competition.
	 */
	static Vector<Animal> AnimalArray = null;
	/**
	 * a BufferedImage field of the background of the competition
	 */
	private BufferedImage background;
	/**
	 * a static String that store the location (path) of the background
	 */
	public static final String PathBackGround = "competitionBackground.png";

	/**
	 * Constructor
	 */
	public CompetitionPanel() {
		super();
		try {
			background = ImageIO.read(new File(PathBackGround));
		} catch (IOException e) {
			System.out.println("Can't load image");
		}
		ObjComPanel = this;
		setSize(1000, 700);
	}
	


	/**
	 * Method that print the vector of the animals to the screen
	 * @param vec- Animals vector
	 */
	public void printVector(Vector<Animal> vec) {
		AnimalArray = vec;
		repaint();
	}

	/**
	 * override method that print every object
	 */
	@Override
	protected void paintComponent(Graphics g) {
		super.paintComponent(g);
		g.drawImage(background, 0, 0, getWidth(), getHeight(), this);
		if (AnimalArray != null) {
			for (int i = 0; i < AnimalArray.size(); i++) {
				AnimalArray.get(i).drawObject(g);
			}
		}
		repaint();
	}

	/**
	 * static method that return the static CompetitionPanel object.
	 * @return
	 */
	public static CompetitionPanel getCompetitionPanel() {
		if (ObjComPanel == null)
			return null;
		return ObjComPanel;
	}
	/***
	 * An override actionperformed method to handle events
	 */
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub

	}
}
