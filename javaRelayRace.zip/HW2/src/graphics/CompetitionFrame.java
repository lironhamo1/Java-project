package graphics;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Dimension;
import java.awt.FlowLayout;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.util.Vector;
import java.util.concurrent.atomic.AtomicBoolean;

import javax.swing.AbstractAction;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import animals.Animal;
import competitions.CourierTournament;
import competitions.RegularTournament;
import competitions.TournamentThread;
import threads.*;

/**
 * 
 * @author Liron Hamo 207973603 and Daniel Assayag 316614320
 *
 */
public class CompetitionFrame extends JFrame implements ActionListener {
	/***
	 * JButton that appear at the competition
	 *
	 */
	JButton competition, addAnimal, clear, eat, info, exitb;
	/***
	 * JMenu that appear at the competition
	 *
	 */
	JMenu file, help;
	/***
	 * a static Vector of animals
	 *
	 */
	static Vector<Animal> AnimalArray = new Vector();
	/***
	 * JPanel for all the buttons in the frame
	 *
	 */
	JPanel buttonP;
	/***
	 * a static CompetitionPanel object
	 *
	 */
	static CompetitionPanel Pcomp;
	/***
	 * a string array of strings for CMB to choose type of the competition
	 */
	String[] typesCompetition = { "choose", "Water", "Land", "Air" };
	/***
	 * a string that store the type of the competition
	 */
	String TypeCompetition = null;
	/***
	 * a JCombobox that appear the animals that in the vector
	 */
	JComboBox<String> AnimalList;
	/***
	 * a JTable that appear info for the animals that in the competiton
	 */
	JTable jtableInfo;
	/***
	 * a Object array that has the Columns of the JTable
	 */
	Object[] titelsJT = { "Animal", "Category", "Type", "Speed", "Distance", "Energy Comsumpt" };
	/***
	 * a Object two-dimensional array for store the data of the JTable
	 */
	Object[][] dataJT;

	/***
	 * Constructor for initial the competition frame.
	 */
	String CompRadio;
	Animal[][] Darray;
	int TeamNum;

	CompetitionFrame() {
		super("CompetitionFrame");
		buttonP = new JPanel();
		Pcomp = new CompetitionPanel();
		this.setLayout(new FlowLayout());
		competition = new JButton(("competition"));
		competition.setPreferredSize(new Dimension(100, 50));
		addAnimal = new JButton(("add animal"));
		addAnimal.setPreferredSize(new Dimension(100, 50));
		clear = new JButton(("clear"));
		clear.setPreferredSize(new Dimension(100, 50));
		eat = new JButton(("eat"));
		eat.setPreferredSize(new Dimension(100, 50));
		info = new JButton(("info"));
		info.setPreferredSize(new Dimension(100, 50));
		exitb = new JButton(("exit"));
		exitb.setPreferredSize(new Dimension(100, 50));
		JButton addCom = new JButton("add competition");
		addCom.setPreferredSize(new Dimension(150, 50));
		buttonP.add(addCom);
		buttonP.add(competition);
		buttonP.add(addAnimal);
		buttonP.add(eat);
		buttonP.add(clear);
		buttonP.add(info);
		buttonP.add(exitb);
		competition.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				AddCompRegularComp();
			}
		});
		addAnimal.addActionListener(this);

		clear.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JPanel panel = new JPanel();
				if (AnimalArray.size() == 0) {

					JOptionPane.showMessageDialog(panel, "There are no Animals");

				} else {
					AnimalList = new JComboBox<String>(getListVector(AnimalArray));
					int removeIndex = 0;
					panel.add(AnimalList);
					int result = JOptionPane.showConfirmDialog(null, panel, "remove", JOptionPane.OK_CANCEL_OPTION,
							JOptionPane.QUESTION_MESSAGE);
					if (result == JOptionPane.OK_OPTION) {
						removeIndex = AnimalList.getSelectedIndex();
					}
					AnimalArray.remove(removeIndex);
					System.out.println("the animal remove");
				}
			}
		});

		eat.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JPanel panel = new JPanel();
				if (AnimalArray.size() == 0) {

					JOptionPane.showMessageDialog(panel, "There are no Animals");

				} else {
					AnimalList = new JComboBox<String>(getListVector(AnimalArray));
					int eatIndex = 0;
					int foodAmount;
					panel.add(AnimalList);
					int result = JOptionPane.showConfirmDialog(null, panel, "type comp", JOptionPane.OK_CANCEL_OPTION,
							JOptionPane.QUESTION_MESSAGE);
					if (result == JOptionPane.OK_OPTION) {
						eatIndex = AnimalList.getSelectedIndex();
					}
					String food = JOptionPane.showInputDialog(panel, "Enter how much food?");
					if (IsInt_ByException(food) == true) {

						foodAmount = Integer.parseInt(food);
					} else {
						foodAmount = 0;
					}

					AnimalArray.get(eatIndex).eat(foodAmount);
					System.out.println("the animal eating");
				}
			}
		});

		info.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JPanel panel = new JPanel();
				dataJT = new Object[AnimalArray.size()][6];
				for (int i = 0; i < AnimalArray.size(); i++) {
					dataJT[i][0] = new String(AnimalArray.elementAt(i).getName());
					dataJT[i][1] = new String(AnimalArray.elementAt(i).returnType());
					dataJT[i][2] = new String(AnimalArray.elementAt(i).returnAnimal());
					dataJT[i][3] = AnimalArray.elementAt(i).getEnergyNow();
					dataJT[i][4] = AnimalArray.elementAt(i).getTotalDistance();
					dataJT[i][5] = AnimalArray.elementAt(i).getConsumptionEnergy();

				}
				jtableInfo = new JTable(dataJT, titelsJT);
				jtableInfo.setFillsViewportHeight(true);
				panel.add(new JScrollPane(jtableInfo));
				JOptionPane.showMessageDialog(null, panel, "Information", JOptionPane.INFORMATION_MESSAGE);
			}
		});

		exitb.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		JMenuBar mb = new JMenuBar();
		JMenuItem exit = new JMenuItem(new AbstractAction("Exit") {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		JMenuItem Message = new JMenuItem(new AbstractAction("Message") {
			public void actionPerformed(ActionEvent e) {
				JFrame fa = new JFrame();
				JOptionPane.showMessageDialog(fa, "hm2\nGUI");
			}
		});
		addCom.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JPanel panel = new JPanel();
				JRadioButton RBCourierTournament = new JRadioButton("Courier Tournament");
				RBCourierTournament.setMnemonic(KeyEvent.VK_B);
				RBCourierTournament.setActionCommand("Courier Tournament");
				RBCourierTournament.setSelected(true);

				JRadioButton RBRegularTournament = new JRadioButton("Regular Tournament");
				RBRegularTournament.setMnemonic(KeyEvent.VK_B);
				RBRegularTournament.setActionCommand("Regular Tournament");
				ButtonGroup group = new ButtonGroup();
				group.add(RBRegularTournament);
				group.add(RBCourierTournament);
				panel.add(RBRegularTournament);
				panel.add(RBCourierTournament);
				// JOptionPane.showMessageDialog(null, panel, "comptition",
				// JOptionPane.INFORMATION_MESSAGE);
				int result = JOptionPane.showConfirmDialog(null, panel, "type competiton", JOptionPane.OK_CANCEL_OPTION,
						JOptionPane.QUESTION_MESSAGE);
				if (result == JOptionPane.OK_OPTION) {
					TypeCompetition = group.getSelection().getActionCommand();
					System.out.println(TypeCompetition);
					if (TypeCompetition == "Regular Tournament") {
						AddCompRegularComp();
						AddAnimalComp();
						vectorToAraay();
						RegularTournament tournament = new RegularTournament(Darray);
					} else {
						AddTeams();
						CourierTournament tournament = new CourierTournament(Darray);
					}
				}
			}

		});

		file = new JMenu("File");
		file.add(exit);
		help = new JMenu("Help");
		help.add(Message);
		mb.add(file);
		mb.add(help);
		Pcomp.setPreferredSize(new Dimension(640, 480));
		add(Pcomp);
		add(buttonP, BorderLayout.SOUTH);
		this.setJMenuBar(mb);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(900, 700);
		setVisible(true);
	}

	private boolean IsInt_ByException(String str) {
		try {
			Integer.parseInt(str);
			return true;
		} catch (NumberFormatException nfe) {
			return false;
		}
	}

	/***
	 * A method that transfers the animal vector to an array
	 * 
	 * @param vec- animal's Vector
	 * @return String array
	 */
	public String[] getListVector(Vector<Animal> vec) {
		String[] StringAnimal = new String[vec.size()];
		for (int i = 0; i < vec.size(); i++) {
			StringAnimal[i] = vec.get(i).getName();
		}
		return StringAnimal;

	}

	/***
	 * main
	 * 
	 * @param args
	 */
	public static void main(String args[]) {
		new CompetitionFrame();
		CompetitionPanel.getCompetitionPanel().repaint();

	}

	/***
	 * An override actionperformed method to handle events
	 */
	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == addAnimal) {
			AddAnimalComp();

			// CourierComp();
			// System.out.println(AnimalArray.size());

		}

	}

	public void competition() {
		for (int i = 0; i < AnimalArray.size(); i++) {
			Thread animalT = new Thread(
					new AnimalThread(AnimalArray.elementAt(i), new AtomicBoolean(true), new AtomicBoolean(true), 50));

			animalT.start();
		}
	}

	/*
	 * public void CourierComp() { System.out.println(AnimalArray.size());
	 * Animal[][] DAanimal=new Animal[1][AnimalArray.size()]; int
	 * n=AnimalArray.size(); for (int i=0;i<n;i++) {
	 * DAanimal[0][i]=AnimalArray.elementAt(i);
	 * 
	 * } CourierTournament a= new CourierTournament(DAanimal);
	 * 
	 * }
	 */

	void AddAnimalComp() {
		AddAnimalDialog addAnimal = new AddAnimalDialog(TypeCompetition);
		int result = JOptionPane.showConfirmDialog(this, addAnimal, "Add Animal", JOptionPane.OK_CANCEL_OPTION);
		if (result == JOptionPane.OK_OPTION) {
			AnimalArray = AddAnimalDialog.vectorAnimal;
			Pcomp.printVector(AnimalArray);
			// competition();
		}
	}

	void AddCompRegularComp() {
		JPanel panel = new JPanel();
		JComboBox CMBcompetition = new JComboBox(typesCompetition);
		CMBcompetition.setEditable(true);
		panel.add(CMBcompetition);
		int result = JOptionPane.showConfirmDialog(null, panel, "type comp", JOptionPane.OK_CANCEL_OPTION,
				JOptionPane.QUESTION_MESSAGE);
		if (result == JOptionPane.OK_OPTION) {
			TypeCompetition = CMBcompetition.getSelectedItem().toString();
		}
	}

	void vectorToAraay() {
		Darray = new Animal[1][AnimalArray.size()];
		for (int i = 0; i < AnimalArray.size(); i++) {
			Darray[0][i] = AnimalArray.elementAt(i);
		}
	
	}

	void vectorTo2Araay(int[] arr) {
		Darray = new Animal[arr.length][];
		int size=0;
		for (int i = 0; i < arr.length; i++) {
			Darray[i] = new Animal[arr[i]];
			for(int j=0;j<arr[i];j++) {
				Darray[i][j]=AnimalArray.get(size);
				size++;
			}
		}
	}

	void AddTeams() {
		JPanel panel = new JPanel();
		int numberofgrupe, numAnimal;
		String numGrupe = JOptionPane.showInputDialog(panel, "Enter number of groupes?");
		if (IsInt_ByException(numGrupe) == true) {
			numberofgrupe = Integer.parseInt(numGrupe);
		} else {
			numberofgrupe = 0;
		}
		int[] arr = new int[numberofgrupe];
		for (int i = 0; i < numberofgrupe; i++) {
			AddCompRegularComp();
			String numanimal = JOptionPane.showInputDialog(panel, "Enter number of animal at group" + (i + 1) + " ?   (in range between 1-3) ");
			if (IsInt_ByException(numanimal) == true) {
				numAnimal = Integer.parseInt(numanimal);
				if (numAnimal<1 || numAnimal>3) {
					JOptionPane.showMessageDialog(this, "ERROR\nthe number must to be in range 1-3");
					System.exit(0);
				}
			} else {
				numAnimal = 0;
			}
			arr[i] = numAnimal;
			for (int j = 0; j < numAnimal; j++) {
				AddAnimalComp();
			}
		}
		vectorTo2Araay(arr);
		
	}

}
