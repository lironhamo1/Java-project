
package graphics;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Window;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import Olympics.Medal;
import animals.Alligator;
import animals.Animal;
import animals.Dolphin;
import animals.Animal.gender;
import animals.Cat;
import animals.Dog;
import animals.Dolphin.WaterType;
import animals.Eagle;
import animals.Pigeon;
import animals.Snake;
import animals.Snake.Poisonous;
import animals.Whale;
import mobility.Point;

/***
 * AddAnimalDialog class that init the animal vector of the competition
 * 
 * @author liron hamo and daniel assayag
 *
 */

public class AddAnimalDialog extends JPanel implements ActionListener {
	
	/***
	 * Medal field of the animal that create
	 */
	Medal[] m = new Medal[0];
	/***
	 * static Point field of the animal that create
	 */
	public static Point p = new Point(0,400);
	/***
	 * a string array of strings for CMB to choose option of alligator's name
	 */
	String[] AlligatorName = { "choose name", "alligator1", "alligator2", "alligator3" };
	/***
	 * a string array of strings for CMB to choose option of cat's name
	 */
	String[] CatName = { "choose name", "cat1", "cat2" };
	/***
	 * a string array of strings for CMB to choose option of dog's name
	 */
	String[] DogName = { "choose name", "dog1", "dog2", "dog3", "dog4", "dog5", "dog6" };
	/***
	 * a string array of strings for CMB to choose option of dolphin's name
	 */
	String[] DolphinName = { "choose name", "dolphin1", "dolphin2", "dolphin3" };
	/***
	 * a string array of strings for CMB to choose option of snake's name
	 */
	String[] SnakeName = { "choose name", "snake1", "snake2", "snake3" };
	/***
	 * a string array of strings for CMB to choose option of whale's name
	 */
	String[] WhaleName = { "choose name", "whale1", "whale2" };
	/***
	 * a string array of strings for CMB to choose option of pigeon's name
	 */
	String[] PigeonName = { "choose name", "pigeon1" };
	/***
	 * a static string array of strings for CMB to choose option of eagle's name
	 */
	static String[] EagleName = { "choose name", "eagle1", "eagle2", "eagle3" };
	/***
	 * a static JCombobox to choose an option of eagle's name
	 */
	static  JComboBox<String> CMBEagle = new JComboBox<String>(EagleName);
	/***
	 * a static JCombobox to choose an option of animal's name
	 */
	static JComboBox<String> CMBname = new JComboBox<String>();
	/***
	 * a string array of strings for CMB to choose option of animal's type
	 */
	String[] typesAnimals = { "choose type", "Water", "Land", "Air" };
	/***
	 * a string array of strings for CMB to choose option of sea animal
	 */
	String[] sea_animals = { "choose Animal", "Alligator", "Dolphin", "Whale" };
	/***
	 * a string array of strings for CMB to choose option of air animal
	 */
	String[] air_animals = { "choose Animal", "Eagle", "Pigeon" };
	/***
	 * a string array of strings for CMB to choose option of land animal
	 */
	String[] land_animals = { "choose Animal", " ", "Cat", "Dog", "Snake" };
	/***
	 * a string array of strings for CMB to choose option of animal's gender
	 */
	String[] genderJ = { "choose gender", "Male", "Female", "Hermaphrodite" };
	/***
	 * a string array of strings for CMB to choose option of dolphine's waterType
	 */
	String[] waterTypeJ = { "choose water Type", "Sea", "Sweet" };
	/***
	 * a string array of strings for CMB to choose option of snake's poisonous level
	 */
	String[] poisonousJ = { "choose poisonous", "high", "medium", "low" };
	/***
	 * a string array of strings for CMB to choose option of air animal route
	 */
	String[] pathAir = { "choose path", "1", "2", "3", "4", "5" };
	/***
	 * a string array of strings for CMB to choose option of water animal route
	 */
	String[] pathWater = { "choose path", "1", "2", "3", "4" };
	/***
	 * a string array of strings for CMB to choose option of cat's castrated
	 * (true\false)
	 */
	String carC[] = { "Is castrated?", "Yes", "No" };
	/***
	 * a JCombobox to choose an option of air animal's route
	 */
	JComboBox<String> CMBpathAir = new JComboBox<String>(pathAir);
	/***
	 * a JCombobox to choose an option of water animal's route
	 */
	JComboBox<String> CMBpathWater = new JComboBox<String>(pathWater);
	/***
	 * a JCombobox to choose an option of cat's castrated state
	 */
	JComboBox<String> CMBcastrated = new JComboBox<String>(carC);
	/***
	 * a JCombobox to choose an option of animal type
	 */
	JComboBox<String> CMBtypesAnimal = new JComboBox<String>(typesAnimals);

	JComboBox<String> CMB_Type_Animal = new JComboBox<String>(sea_animals);

	/***
	 * a JCombobox to choose an animal's gender from genders options
	 */
	JComboBox<String> CMBgenderType = new JComboBox<String>(genderJ);
	/***
	 * a JCombobox to choose a dolphin's watertype
	 */
	JComboBox<String> CMBwaterType = new JComboBox<String>(waterTypeJ);
	/***
	 * a JCombobox to choose a snake's poisenous level
	 */
	JComboBox<String> CMBpoisonous = new JComboBox<String>(poisonousJ);

	// public static JTextField naemtxt = new JTextField("name");

	/***
	 * a static JTextField to Field for filling animal's weight
	 */
	public static JTextField Weighttxt = new JTextField("Weight");
	/***
	 * a static JTextField to Field for filling animal's field
	 */
	public static JTextField generalAnimal = new JTextField();
	
	// public static JTextField generalType = new JTextField();

	/***
	 * a JTextField to Field for filling animal's speed
	 */
	public static JTextField speedtxt = new JTextField("speed");
	/***
	 * a JTextField to Field for filling animal's max energy
	 */
	public static JTextField energytxtew = new JTextField("MAX energy");
	/***
	 * a JTextField to Field for filling animal's energy per meter
	 */
	public static JTextField energyPerMeter = new JTextField("energy per meter");
	/***
	 * a JTextField to Field for filling air animal's wingspan
	 */
	public static JTextField wingspantxt = new JTextField("wingspan");
	/***
	 * a JTextField to Field for filling pogeon's family
	 */
	public static JTextField familytxt = new JTextField("family");
	/***
	 * a JTextField to Field for filling dog's breed
	 */
	public static JTextField breedtxt = new JTextField("breed");
	/***
	 * a JTextField to Field for filling land animal's number of legs
	 */
	public static JTextField noLegstxt = new JTextField("number of legs");
	/***
	 * a JTextField to Field for filling snake's lengyh
	 */
	public static JTextField lengthtxt = new JTextField("length");
	/***
	 * A Poisonous(enum) field that describe the poisonous of the snake
	 */
	static public Poisonous poisonous;
	/***
	 * A WaterType(enum) field that describe the water type of the dolphine
	 */
	static public WaterType watertype;
	/***
	 * A gender(enum) field that describe the animal's gender
	 */
	public static gender genders;
	/***
	 * A boolean field that describe the cat castrated state
	 */
	public static boolean Castrated;
	/***
	 * a JTextField to Field for filling alligator area of living
	 */
	static public JTextField AreaOfLivingtxt = new JTextField("Area Of Living");
	/***
	 * a JTextField to Field for filling water animal divedept
	 */
	static public JTextField diveDepttxt = new JTextField("diveDept");
	/***
	 * a JTextField to Field for filling whale's food type
	 */
	static public JTextField foodTypetxt = new JTextField("food Typet");
	/***
	 * a JTextField to Field for filling the altitude Of flight of the Eagle
	 *
	 */
	static public JTextField altitudeOfFlighttx = new JTextField("altitude Of Flight");
	/***
	 * a String that store the chosen animal
	 *
	 */
	static String choosenAnimal = null;
	/***
	 * a String that store the competition type
	 *
	 */
	String typeComp = "NULL";
	/***
	 * a String that store the chosen animal from the jcombobox
	 *
	 */
	String animalCohice;
	/***
	 * a String that store the animal's name
	 *
	 */
	public static String nameS;
	/***
	 * a JButton that cause to the animal be create
	 *
	 */
	JButton create = new JButton("create");
	/***
	 * a Vector of animals that created
	 *
	 */
	static Vector<Animal> vectorAnimal = new Vector<Animal>();
	/***
	 * an Animal object
	 *
	 */
	static Animal animalObj;
	/***
	 * a double divedept to store the divedept from JTextfield
	 *
	 */
	Double divedept;
	/***
	 * a JCombobox to choose a dog's name
	 */
	JComboBox<String> CMBDog = new JComboBox<String>(DogName);
	/***
	 * a Point array of point for the air animals location
	 */
	Point[] airPointArray = { new Point(0, 0), new Point(0, 100), new Point(0, 200), new Point(0, 300), new Point(0, 400) };
	/***
	 * a Point array of point for the water animals location
	 */
	Point[] waterPointArray = { new Point(0, 40), new Point(0, 140), new Point(0, 240), new Point(0, 340) };

	/***
	 * Constructor
	 * 
	 * @param typeCompetitio- type of the competition that chosen
	 */

	public AddAnimalDialog(String typeCompetition) {
		this.typeComp = typeCompetition;
		CMBtypesAnimal.setEditable(true);
		add(CMBtypesAnimal);
		setLayout(new GridLayout(10, 1));
		setSize(300, 600);
		chooseTypeAnimal(typeComp);
		CMB_Type_Animal.addActionListener(this);
		add(Weighttxt);
		add(speedtxt);
		add(energytxtew);
		add(energyPerMeter);
		add(CMBgenderType);
		add(generalAnimal);
		generalAnimal.setVisible(false);
		add(foodTypetxt);
		foodTypetxt.setVisible(false);
		add(CMBwaterType);
		CMBwaterType.setVisible(false);
		
		add(noLegstxt);
		noLegstxt.setVisible(false);
		add(breedtxt);
		breedtxt.setVisible(false);
		add(lengthtxt);
		lengthtxt.setVisible(false);
		add(CMBpoisonous);
		CMBpoisonous.setVisible(false);
		add(CMBcastrated);
		CMBcastrated.setVisible(false);
		add(altitudeOfFlighttx);
		altitudeOfFlighttx.setVisible(false);
		add(wingspantxt);
		wingspantxt.setVisible(false);
		add(familytxt);
		add(diveDepttxt);
		diveDepttxt.setVisible(false);
		familytxt.setVisible(false);
		add(AreaOfLivingtxt);
		AreaOfLivingtxt.setVisible(false);
		add(CMBpathAir);
		CMBpathAir.setVisible(false);
		add(CMBEagle);
		CMBEagle.setVisible(false);
		CMBpathAir.addActionListener(this);
		add(CMBpathWater);
		CMBpathWater.setVisible(false);
		CMBpathWater.addActionListener(this);
		add(CMBDog);
		CMBDog.setVisible(false);
		add(create);
		create.addActionListener(this);
		add(new JLabel("to start the competition press OK"));
	}
	


	/***
	 * A method for choose type animal (water\land\air)
	 * 
	 * @param comp
	 */
	public void chooseTypeAnimal(String comp) {
		int result = JOptionPane.showConfirmDialog(null, this, "Animal type ", JOptionPane.OK_CANCEL_OPTION,
				JOptionPane.QUESTION_MESSAGE);
		if (result == JOptionPane.OK_OPTION) {
			String Animal = CMBtypesAnimal.getSelectedItem().toString();
			if (Animal != comp) {
				JOptionPane.showMessageDialog(this, "ERROR\nthe animal is'nt fit to the competition");
				setVisible(false);
			} else {
				setVisible(true);
				switch (comp) {
				
				case "Water":
					CMB_Type_Animal = new JComboBox<String>(sea_animals);
					add(CMB_Type_Animal);
					

					break;
				case "Land":
					CMB_Type_Animal = new JComboBox<String>(land_animals);
					add(CMB_Type_Animal);
					

					break;
				case "Air":
					CMB_Type_Animal = new JComboBox<String>(air_animals);
					add(CMB_Type_Animal);
					
					break;
				}
			}
		}
	}

	/***
	 * An override actionperformed method to handle events
	 */
	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == CMB_Type_Animal) {
			animalCohice = CMB_Type_Animal.getSelectedItem().toString();
			addFields(typeComp, animalCohice);
		}

		if (e.getSource() == create) {
			int temp = CMBgenderType.getSelectedIndex();
			switch (temp) {
			case 1:
				genders = genders.Male;
				break;
			case 2:
				genders = genders.Female;
				break;
			case 3:
				genders = genders.Hermaphrodite;
				break;
			}
			Double weight = Double.parseDouble(Weighttxt.getText());
			Double speed = Double.parseDouble(speedtxt.getText());
			int maxEnergy = Integer.parseInt(energytxtew.getText());
			int energyPetMet = Integer.parseInt(energyPerMeter.getText());

			int NameAnimal = CMB_Type_Animal.getSelectedIndex();
			switch (typeComp) {
			case "Air":
				Double wingspan = Double.parseDouble(wingspantxt.getText());
				switch (NameAnimal) {
				case 1:
					Double altitudeOfFlight = Double.parseDouble(altitudeOfFlighttx.getText());
					animalObj = new Eagle(nameS, genders, weight, speed, m, p, wingspan, altitudeOfFlight, maxEnergy,
							energyPetMet, 65);
					System.out.println("Eagle");
					break;
				case 2:
					String Family = familytxt.getText();
					animalObj = new Pigeon(nameS, genders, weight, speed, m, p, wingspan, Family, maxEnergy,
							energyPetMet, 65);
					System.out.println("Pigeon");
					break;
				}
				break;
			case "Water":
				divedept = Double.parseDouble(diveDepttxt.getText());
				switch (NameAnimal) {
				case 1:
					int numLeg = Integer.parseInt(noLegstxt.getText());
					String areaa = AreaOfLivingtxt.getText();
					animalObj = new Alligator(nameS, genders, weight, speed, m, p, divedept, areaa, numLeg, maxEnergy,
							energyPetMet, 65);
					System.out.println("alligator");
					break;

				case 2:
					System.out.println(p.toString());
					animalObj = new Dolphin(nameS, genders, weight, speed, m, p, divedept, watertype, maxEnergy,
							energyPetMet, 65);
					System.out.println("Dolphin");
					break;
				case 3:
					String Food = foodTypetxt.getText();
					animalObj = new Whale(nameS, genders, weight, speed, m, p, divedept, Food, maxEnergy, energyPetMet,
							65);
					System.out.println("Whale");
					break;
				}
				break;
			case "Land":
				int nologs = Integer.parseInt(noLegstxt.getText());
				switch (NameAnimal) {
				case 1:
					Double divedept1 = Double.parseDouble(diveDepttxt.getText());
					String areaa = AreaOfLivingtxt.getText();
					animalObj = new Alligator(nameS, genders, weight, speed, m, p, divedept1, areaa, nologs, maxEnergy,
							energyPetMet, 65);
					System.out.println("alligator");
					break;
				case 2:
					System.out.println(nameS);
					animalObj = new Cat(nameS, genders, weight, speed, m, p, nologs, Castrated, maxEnergy, energyPetMet,
							65);
					System.out.println("Cat");
					break;

				case 3:
					String breed = breedtxt.getText();
					animalObj = new Dog(nameS, genders, weight, speed, m, p, nologs, breed, maxEnergy, energyPetMet,
							65);
					System.out.println("Dog");
					break;
				case 4:
					Double length = Double.parseDouble(lengthtxt.getText());
					animalObj = new Snake(nameS, genders, weight, speed, m, p, nologs, poisonous, length, maxEnergy,
							energyPetMet, 65);
					System.out.println("Snake");
					break;
				}
			}
			p = new Point(0, 400);
			vectorAnimal.addElement(animalObj);
		}

		if (e.getSource() == CMBgenderType) {
			if (CMBgenderType.getSelectedItem().toString() == genderJ[1]) {
				genders = gender.Male;
			} else if (CMBgenderType.getSelectedItem().toString() == genderJ[2]) {
				genders = gender.Female;

			} else if (CMBgenderType.getSelectedItem().toString() == genderJ[3]) {
				genders = gender.Hermaphrodite;
			}
		}
		if (e.getSource() == CMBpoisonous) {
			if (CMBpoisonous.getSelectedItem().toString() == poisonousJ[1]) {
				poisonous = Poisonous.high;
			} else if (CMBpoisonous.getSelectedItem().toString() == poisonousJ[2]) {
				poisonous = Poisonous.medium;

			} else if (CMBpoisonous.getSelectedItem().toString() == poisonousJ[3]) {
				poisonous = Poisonous.low;
			}
		}

		if (e.getSource() == CMBwaterType) {
			if (CMBwaterType.getSelectedItem().toString() == waterTypeJ[1]) {
				watertype = WaterType.Sea;
			} else if (CMBwaterType.getSelectedItem().toString() == waterTypeJ[2]) {
				watertype = WaterType.Sweet;
			}
		}
		if (e.getSource() == CMBcastrated) {
			if (CMBcastrated.getSelectedItem().toString() == carC[1]) {
				Castrated = true;
			} else if (CMBcastrated.getSelectedItem().toString() == carC[2]) {
				Castrated = false;
			}
		}

		if (e.getSource() == CMBpathAir) {
			if (CMBpathAir.getSelectedItem().toString() == "1") {
				p = airPointArray[0];
			} else if (CMBpathAir.getSelectedItem().toString() == "2") {
				p = airPointArray[1];
			} else if (CMBpathAir.getSelectedItem().toString() == "3") {
				p = airPointArray[2];
			} else if (CMBpathAir.getSelectedItem().toString() == "4") {
				p = airPointArray[3];
			} else if (CMBpathAir.getSelectedItem().toString() == "5") {
				p = airPointArray[4];
			}
		}
		if (e.getSource() == CMBpathWater) {
			//System.out.println("enter");
			if (CMBpathWater.getSelectedItem().toString() == "1") {
				p = waterPointArray[0];
			} else if (CMBpathWater.getSelectedItem().toString() == "2") {
				p = waterPointArray[1];
			} else if (CMBpathWater.getSelectedItem().toString() == "3") {
				p = waterPointArray[2];
			} else if (CMBpathWater.getSelectedItem().toString() == "4") {
				p = waterPointArray[3];
			}
		}
		if (e.getSource() == CMBname) {
			nameS = CMBname.getSelectedItem().toString();
		}
		if (e.getSource() == CMBDog) {
			nameS = CMBDog.getSelectedItem().toString();
		}
		if (e.getSource() == CMBEagle) {
			nameS = CMBEagle.getSelectedItem().toString();
		}
	}

	public void addFields(String type, String animal) {
		if (type == "Water") {
			CMBpathWater.setVisible(true);
			diveDepttxt.setVisible(true);
			if (animal == "Dolphin") {
				CMBname = new JComboBox<String>(DolphinName);
				add(CMBname);
				CMBname.addActionListener(this);
				CMBwaterType.setVisible(true);
			} else if (animal == "Whale") {
				CMBname = new JComboBox<String>(WhaleName);
				add(CMBname);
				CMBname.addActionListener(this);
				foodTypetxt.setVisible(true);
			} else if (animal == "Alligator") {
				CMBname = new JComboBox<String>(AlligatorName);
				add(CMBname);
				CMBname.addActionListener(this);
				noLegstxt.setVisible(true);
				AreaOfLivingtxt.setVisible(true);
			}
		} else if (type == "Land") {
			noLegstxt.setVisible(true);
			/*
			 * if (animal == land_animals[1]) {// Alligator CMBname=new
			 * JComboBox<String>(AlligatorName); add(CMBname);
			 * CMBname.addActionListener(this); CMBname.setVisible(true);
			 * AreaOfLivingtxt.setVisible(true); diveDepttxt.setVisible(true);
			 */
			if (animal == land_animals[2]) {// Cat
				CMBname = new JComboBox<String>(CatName);
				add(CMBname);
				CMBname.addActionListener(this);
				CMBcastrated.setVisible(true);
			} else if (animal == land_animals[3]) {// Dog
				JPanel a = new JPanel();
				CMBDog.setVisible(true);
				CMBDog.addActionListener(this);
				breedtxt.setVisible(true);
			} else if (animal == land_animals[4]) {// Snake
				CMBname = new JComboBox<String>(SnakeName);
				add(CMBname);
				CMBname.addActionListener(this);
				lengthtxt.setVisible(true);
				CMBpoisonous.setVisible(true);
			}
		} else if (type == "Air") {
			CMBpathAir.setVisible(true);
			wingspantxt.setVisible(true);
			if (animal == air_animals[1]) {// eagle
				CMBEagle.setVisible(true);
				CMBEagle.addActionListener(this);
				altitudeOfFlighttx.setVisible(true);
			} else if (animal == air_animals[2]) {// pigeon
				CMBname = new JComboBox<String>(PigeonName);
				add(CMBname);
				familytxt.setVisible(true);
			}
		}
	}
}