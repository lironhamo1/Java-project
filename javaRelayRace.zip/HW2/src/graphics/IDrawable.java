package graphics;

import java.awt.Graphics;

public interface IDrawable {
	/**
	 * static string that store the path of the imgs
	 */
	public final static String PICTURE_PATH="src/graphics/pictures/"; 
	/**
	 * method that load the image from the file to the project
	 * @param nm- name of the img that need to load.
	 */
	public void loadImages(String nm);
	/**
	 * method that draw the object on the screen
	 * @param g
	 */
	public void drawObject (Graphics g);
}
