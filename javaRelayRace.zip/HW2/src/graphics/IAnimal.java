package graphics;

public interface IAnimal {
	public boolean eat(int energy);

}
